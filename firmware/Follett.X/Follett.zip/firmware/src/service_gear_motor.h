
#ifndef SERVICE_GEAR_MOTOR_H    /* Guard against multiple inclusion */
#define SERVICE_GEAR_MOTOR_H

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

void updateGearMotor(void);
    
/* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */



