
#ifndef SELF_HELP_H    /* Guard against multiple inclusion */
#define SELF_HELP_H

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif
void selfHelpMenuAlert(void);


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
