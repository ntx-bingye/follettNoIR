
#ifndef SPLASH_HOTWATER_H    /* Guard against multiple inclusion */
#define SPLASH_HOTWATER_H

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

void updateHotWaterStatus(void);

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
