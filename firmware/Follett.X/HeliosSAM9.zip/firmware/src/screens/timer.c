#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "app.h"

extern int PreviousScreen;

static uint32_t counter;
uint32_t        EggTimerData = 0;
static char     EggTimerDataString[8] = "000";
static uint8_t  EggTimerDataStringNDX = 0;

static SYS_TIME_HANDLE eggTimer       = SYS_TIME_HANDLE_INVALID;
// static SYS_TIME_HANDLE countDownTimer = SYS_TIME_HANDLE_INVALID;
static void eggTimerCallback(uintptr_t context);
// static void countDownTimerCallback(uintptr_t context);

// static void countDownTimerCallback(uintptr_t context)
// {
// }

static void eggTimerCallback(uintptr_t context)
{
  counter++;
  if(EggTimerData != 0)
  {
    EggTimerData--;
  }
  else
  { // egg timer expired
    // doug notify USER!!! (Only once
    //      beeps
    //      BLINK
    //      etc...
    counter = 0;
    LED_YELLOW_Off();
    SYS_TIME_TimerStop(eggTimer); // stop serial timer
    // TemperatureModeSingle_ButtonTimerRemaining->fn->setVisible
    //   (TemperatureModeSingle_ButtonTimerRemaining, LE_FALSE);
    // PowerModeSingle_ButtonTimerRemaining->fn->setVisible
    //   (PowerModeSingle_ButtonTimerRemaining, LE_FALSE);
  }
}

void event_TimerInit_ButtonExit_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Exit\r\n");
}

void event_TimerInit_ButtonExit_OnReleased(leButtonWidget* btn)
{
  printf("released Exit\r\n");
  printf("PreviousScreen: %d\r\n", PreviousScreen);
  printf("released Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
  if(PreviousScreen == screenID_PowerModeSingle)
  {
    legato_showScreen(screenID_PowerModeSingle);
  }
  else if(PreviousScreen == screenID_TemperatureModeSingle)
  {
    legato_showScreen(screenID_TemperatureModeSingle);
  }
  else
  {
    printf("PreviousScreen: %d\r\n", PreviousScreen);
  }

  // doug --- zero out on Exit???
  EggTimerData = 0;
  memset(EggTimerDataString, 0, sizeof(EggTimerDataString));
}


void event_TimerInit_ButtonKeyEnter_OnPressed(leButtonWidget* btn)
{
  // printf("pressed EnterTime: %s %d\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKeyEnter_OnReleased(leButtonWidget* btn)
{
  printf("released Enter\r\n");
  printf("PreviousScreen: %d\r\n", PreviousScreen);
  printf("released Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
  if(EggTimerData > 300)
  {
    EggTimerData = 300;
    strcpy(EggTimerDataString, "300");
  }
  if(EggTimerData > 0)
  {
    LED_YELLOW_On();
  }

  printf("released Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);

  // check if serial timer valid
  if(eggTimer != SYS_TIME_HANDLE_INVALID)
  {
    SYS_TIME_TimerStop(eggTimer);       // stop serial timer
    SYS_TIME_TimerDestroy(eggTimer);    // delete serial timer
    eggTimer = SYS_TIME_HANDLE_INVALID; // invalidate serial timer
  }


  // assign serial timer callback (1 minute timeout)
  // eggTimer = SYS_TIME_CallbackRegisterMS(eggTimerCallback, 0, 60000, SYS_TIME_SINGLE);
  eggTimer = SYS_TIME_CallbackRegisterMS(eggTimerCallback, 0, 60000, SYS_TIME_PERIODIC);
  SYS_TIME_TimerStart(eggTimer); // stop serial timer

  if(PreviousScreen == screenID_PowerModeSingle)
  {
    legato_showScreen(screenID_PowerModeSingle);
  }
  else if(PreviousScreen == screenID_TemperatureModeSingle)
  {
    legato_showScreen(screenID_TemperatureModeSingle);
  }
  else
  {
    printf("PreviousScreen: %d\r\n", PreviousScreen);
  }
}


void event_TimerInit_ButtonKeyBackSpace_OnPressed(leButtonWidget* btn)
{
  printf("released Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKeyBackSpace_OnReleased(leButtonWidget* btn)
{
  // doug --- need logic here
  if((EggTimerDataStringNDX >= 0) && (EggTimerDataStringNDX < 3))
    EggTimerDataString[EggTimerDataStringNDX] = 0;
  if(EggTimerDataStringNDX > 0)
    EggTimerDataStringNDX--;
  EggTimerData = EggTimerData / 10;
  printf("released BackSpace %s %lu\r\n", EggTimerDataString, EggTimerData);
}


void event_TimerInit_ButtonKey0_OnPressed(leButtonWidget* btn)
{
  printf("pressed 0 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey0_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    if(EggTimerDataStringNDX > 0)
    {
      EggTimerDataString[EggTimerDataStringNDX++] = 0x30;
      EggTimerData = EggTimerData * 10 + 0;
    }
  }
  printf("released 0 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey1_OnPressed(leButtonWidget* btn)
{
  printf("pressed 1 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey1_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x31;
    EggTimerData = EggTimerData * 10 + 1;
  }
  printf("released 1 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey2_OnPressed(leButtonWidget* btn)
{
  printf("pressed 2 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey2_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x32;
    EggTimerData = EggTimerData * 10 + 2;
  }
  printf("released 2 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey3_OnPressed(leButtonWidget* btn)
{
  printf("pressed 3 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey3_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x33;
    EggTimerData = EggTimerData * 10 + 3;
  }
  printf("released 3 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey4_OnPressed(leButtonWidget* btn)
{
  printf("pressed 4 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey4_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x34;
    EggTimerData = EggTimerData * 10 + 4;
  }
  printf("released 4 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey5_OnPressed(leButtonWidget* btn)
{
  printf("pressed 5 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey5_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x35;
    EggTimerData = EggTimerData * 10 + 5;
  }
  printf("released 5 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey6_OnPressed(leButtonWidget* btn)
{
  printf("pressed 6 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey6_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x36;
    EggTimerData = EggTimerData * 10 + 6;
  }
  printf("released 6 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey7_OnPressed(leButtonWidget* btn)
{
  printf("pressed 7 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey7_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x37;
    EggTimerData = EggTimerData * 10 + 7;
  }
  printf("released 7 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey8_OnPressed(leButtonWidget* btn)
{
  printf("pressed 8 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey8_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x38;
    EggTimerData = EggTimerData * 10 + 8;
  }
  printf("released 8 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey9_OnPressed(leButtonWidget* btn)
{
  printf("pressed 9 %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void event_TimerInit_ButtonKey9_OnReleased(leButtonWidget* btn)
{
  if(EggTimerDataStringNDX<3)
  {
    EggTimerDataString[EggTimerDataStringNDX++] = 0x39;
    EggTimerData = EggTimerData * 10 + 9;
  }
  printf("released 9 Timer: %s %lu\r\n", EggTimerDataString, EggTimerData);
}

void TimerInit_OnShow()
{
  EggTimerDataStringNDX = 0;
  memset(EggTimerDataString, 0, sizeof(EggTimerDataString));
  EggTimerData = 0;
}






















/*******************************************************************************
 End of File
 */



