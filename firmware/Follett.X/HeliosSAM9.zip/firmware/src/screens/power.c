#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "app.h"
#include "peripheral/pwm/plib_pwm.h"

extern int PreviousScreen;
extern uint16_t EggTimerData;

static bool unlockScreenTimerExpired = false;
static SYS_TIME_HANDLE unlockScreenTimer = SYS_TIME_HANDLE_INVALID;
static void unlockScreenTimerCallback(uintptr_t context);
static int oneTimeInit;

static char cActPowerBuffer[20];
static leChar legatoActPowerBuffer[20] = {0};
static leFixedString actPowerString;

int powerLevelValue;
int actualPower;
int  lastPosition;
int newPosition;
bool frontWarmerOn;
bool rearWarmerOn;
static void unlockScreenTimerCallback(uintptr_t context)
{ // show SelectOperationaCooklMode screen
  unlockScreenTimerExpired = true;
}

void event_PowerModeSingle_ButtonTimer_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Timer Power\r\n");
}

void event_PowerModeSingle_ButtonTimer_OnReleased(leButtonWidget* btn)
{
  // printf("released Timer Power\r\n");
  PreviousScreen = screenID_PowerModeSingle;
  legato_showScreen(screenID_TimerInit);
}


void event_PowerModeSingle_ButtonLockScreen_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Lock Power\r\n");
  PowerModeSingle_ButtonLockScreen->fn->setReleasedImage
    (PowerModeSingle_ButtonLockScreen, (leImage*)&ICON_lockClosed);
  // assign 5 second screen timer
  unlockScreenTimerExpired = false;
  unlockScreenTimer = SYS_TIME_CallbackRegisterMS(unlockScreenTimerCallback, 0 , 3000, SYS_TIME_SINGLE);
}

void event_PowerModeSingle_ButtonLockScreen_OnReleased(leButtonWidget* btn)
{
  // printf("released Lock Power\r\n");

  // check if unlock time satified
  if(unlockScreenTimerExpired)
  {
    PowerModeSingle_ButtonLockScreen->fn->setReleasedImage
      (PowerModeSingle_ButtonLockScreen, (leImage*)&ICON_lockOpen);
    PowerModeSingle_ButtonSettings->fn->setEnabled(PowerModeSingle_ButtonSettings, LE_TRUE);
    PowerModeSingle_ButtonBack->fn->setEnabled(PowerModeSingle_ButtonBack, LE_TRUE);
    PowerModeSingle_ButtonTimer->fn->setEnabled(PowerModeSingle_ButtonTimer, LE_TRUE);
    PowerModeSingle_PowerSlider->fn->setEnabled(PowerModeSingle_PowerSlider, LE_TRUE);
  }
  else
  {
    PowerModeSingle_ButtonSettings->fn->setEnabled(PowerModeSingle_ButtonSettings, LE_FALSE);
    PowerModeSingle_ButtonBack->fn->setEnabled(PowerModeSingle_ButtonBack, LE_FALSE);
    PowerModeSingle_ButtonTimer->fn->setEnabled(PowerModeSingle_ButtonTimer, LE_FALSE);
    PowerModeSingle_PowerSlider->fn->setEnabled(PowerModeSingle_PowerSlider, LE_FALSE);
  }
}


void event_PowerModeSingle_ButtonSettings_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Settings Power\r\n");
}

void event_PowerModeSingle_ButtonSettings_OnReleased(leButtonWidget* btn)
{
  printf("released Settings Power\r\n");
  // show next screen
  PreviousScreen = screenID_PowerModeSingle;
  printf("PreviousScreen: %d\r\n", PreviousScreen);
  legato_showScreen(screenID_Settings);
}


void event_PowerModeSingle_ButtonBack_OnPressed(leButtonWidget* btn)
{
  EggTimerData = 0;
}

void event_PowerModeSingle_ButtonBack_OnReleased(leButtonWidget* btn)
{
  legato_showScreen(screenID_SelectCookMode);
}


void PowerModeSingle_OnShow()
{
  // enable/disable buttons
  PowerModeSingle_ButtonSettings->fn->setEnabled(PowerModeSingle_ButtonSettings, LE_TRUE);
  PowerModeSingle_ButtonBack->fn->setEnabled(PowerModeSingle_ButtonBack, LE_TRUE);
  PowerModeSingle_ButtonLockScreen->fn->setEnabled(PowerModeSingle_ButtonLockScreen, LE_TRUE);
  PowerModeSingle_ButtonTimer->fn->setEnabled(PowerModeSingle_ButtonTimer, LE_TRUE);
  PowerModeSingle_PowerSlider->fn->setEnabled(PowerModeSingle_PowerSlider, LE_TRUE);

  PWM_ChannelDutySet(PWM_CHANNEL_2,0); // White
  PWM_ChannelDutySet(PWM_CHANNEL_3,500); // Red
                    
  if(oneTimeInit == 0)
  {
        oneTimeInit=true;
        leFixedString_Constructor(&actPowerString, legatoActPowerBuffer, 20);
        actPowerString.fn->setFont(&actPowerString, leStringTable_GetStringFont(leGetState()->stringTable,stringID_PowerValue, 0));     
  }
  
  // set button behavior
  PowerModeSingle_ButtonLockScreen->fn->setPressedImage(PowerModeSingle_ButtonLockScreen, (leImage*)&ICON_lockClosed);
  PowerModeSingle_ButtonLockScreen->fn->setReleasedImage(PowerModeSingle_ButtonLockScreen, (leImage*)&ICON_lockOpen);

  // check eggTimer status
  if(EggTimerData > 0)
  {
    PowerModeSingle_ButtonTimerRemaining->fn->setVisible
      (PowerModeSingle_ButtonTimerRemaining, LE_TRUE);

    // doug display the timer widget with data
    // clock icon is enabled
    // HH:MM displayed
    // dismissed by touching timer button
  }
  else
  {
    PowerModeSingle_ButtonTimerRemaining->fn->setVisible
     (PowerModeSingle_ButtonTimerRemaining, LE_FALSE);
  }
  
  //powerLevelValue=0;
  actualPower=0;
  lastPosition=0;
  newPosition=0;
  frontWarmerOn=true;
  rearWarmerOn=false;
  
  PowerModeSingle_PowerSlider->fn->setStartAngle(PowerModeSingle_PowerSlider, 90);
  
}

void event_PowerModeSingle_PowerSlider_OnValueChanged(leCircularSliderWidget* sld, int32_t val)
{
   powerLevelValue = 100-val;
   printf("Power: %d", (int)powerLevelValue);
   
   sprintf(cActPowerBuffer,"%d%%", powerLevelValue);
   actPowerString.fn->setFromCStr(&actPowerString, cActPowerBuffer);
   PowerModeSingle_LabelSetPoint->fn->setString(PowerModeSingle_LabelSetPoint, (leString*)&actPowerString); 
    
}
/*******************************************************************************
 End of File
 */



