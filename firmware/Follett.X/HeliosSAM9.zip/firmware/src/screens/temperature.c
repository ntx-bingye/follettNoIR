#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "app.h"
#include "temperature.h"
#include "peripheral/pwm/plib_pwm.h"

extern int PreviousScreen;
extern uint16_t EggTimerData;
extern bool frontWarmerOn;

static bool unlockScreenTimerExpired = false;
static SYS_TIME_HANDLE unlockScreenTimer = SYS_TIME_HANDLE_INVALID;
static void unlockScreenTimerCallback(uintptr_t context);

static int oneTimeInit;

static char cSetTempBuffer[20];
static leChar legatoSetTempBuffer[20] = {0};
static leFixedString setTempString;

static char cActTempBuffer[20];
static leChar legatoActTempBuffer[20] = {0};
static leFixedString actTempString;

int tempValue;
int setTempValue;
int tempUnits;

void TemperatureModeSingle_OnShow()
{
    frontWarmerOn=true;
    
    PWM_ChannelDutySet(PWM_CHANNEL_2,0); // White
    PWM_ChannelDutySet(PWM_CHANNEL_3,500); // Red
  
    // enable/disable buttons
    TemperatureModeSingle_ButtonSettings->fn->setEnabled(TemperatureModeSingle_ButtonSettings, LE_TRUE);
    TemperatureModeSingle_ButtonBattery->fn->setEnabled(TemperatureModeSingle_ButtonBattery, LE_FALSE);
    TemperatureModeSingle_ButtonBack->fn->setEnabled(TemperatureModeSingle_ButtonBack, LE_TRUE);
    TemperatureModeSingle_ButtonLockScreen->fn->setEnabled(TemperatureModeSingle_ButtonLockScreen, LE_TRUE);
    TemperatureModeSingle_ButtonTimer->fn->setEnabled(TemperatureModeSingle_ButtonTimer, LE_TRUE);
    TemperatureModeSingle_TempSlider->fn->setEnabled(TemperatureModeSingle_TempSlider, LE_TRUE);

    if(!oneTimeInit)
    {
        oneTimeInit=true;
        leFixedString_Constructor(&setTempString, legatoSetTempBuffer, 20);
        setTempString.fn->setFont(&setTempString, leStringTable_GetStringFont(leGetState()->stringTable,stringID_TemperatureSet, 0));
    
        leFixedString_Constructor(&actTempString, legatoActTempBuffer, 20);
        actTempString.fn->setFont(&actTempString, leStringTable_GetStringFont(leGetState()->stringTable,stringID_TemperatureCurrent, 0));        
    }
    
    // Update the temperature on the screen before we show the screen the first time.
    tempUpdate();
    
    // set button behavior
    TemperatureModeSingle_ButtonLockScreen->fn->setPressedImage(TemperatureModeSingle_ButtonLockScreen, (leImage*)&ICON_lockClosed);
    TemperatureModeSingle_ButtonLockScreen->fn->setReleasedImage(TemperatureModeSingle_ButtonLockScreen, (leImage*)&ICON_lockOpen);
    
    // check eggTimer status
    if(EggTimerData > 0)
    {
        TemperatureModeSingle_ButtonTimerRemaining->fn->setVisible
          (TemperatureModeSingle_ButtonTimerRemaining, LE_TRUE);
        
        // doug display the timer widget with data
        // clock icon is enabled
        // HH:MM displayed
        // dismissed by touching timer button
    }
    else
    {
        TemperatureModeSingle_ButtonTimerRemaining->fn->setVisible(TemperatureModeSingle_ButtonTimerRemaining, LE_FALSE);
    }
}

void tempUpdate()
{
    // This function is called every second when this screen is active
    
    // Copy the set temp into a buffer
    if(tempValue<setTempValue)
    {
        tempValue++;
    }
    else if(tempValue>setTempValue)
    {
        tempValue--;
    }

    if(tempUnits == 0)
    {
        sprintf(cActTempBuffer,"%d�F", tempValue);
        sprintf(cSetTempBuffer,"Set: %d�F", setTempValue);
    }
    else
    {
        // TODO Convert to C
        sprintf(cActTempBuffer,"%d�C", tempValue);
        sprintf(cSetTempBuffer,"Set: %d�C", setTempValue);
    }
    
    setTempString.fn->setFromCStr(&setTempString, cSetTempBuffer);
    TemperatureModeSingle_LabelTemperatureSet->fn->setString(TemperatureModeSingle_LabelTemperatureSet, (leString*)&setTempString); 
    
    actTempString.fn->setFromCStr(&actTempString, cActTempBuffer);
    TemperatureModeSingle_LabelTemperatureCurrent->fn->setString(TemperatureModeSingle_LabelTemperatureCurrent, (leString*)&actTempString); 
}

static void unlockScreenTimerCallback(uintptr_t context)
{ // show SelectOperationaCooklMode screen
  unlockScreenTimerExpired = true;
}

void event_TemperatureModeSingle_ButtonTimer_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Timer Temperature\r\n");
}

void event_TemperatureModeSingle_ButtonTimer_OnReleased(leButtonWidget* btn)
{    
  // printf("release Timer Temperature\r\n");
  PreviousScreen = screenID_TemperatureModeSingle;
  legato_showScreen(screenID_TimerInit);
}


void event_TemperatureModeSingle_ButtonLockScreen_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Lock Power\r\n");
  TemperatureModeSingle_ButtonLockScreen->fn->setReleasedImage
    (TemperatureModeSingle_ButtonLockScreen, (leImage*)&ICON_lockClosed);
  // assign 5 second screen timer
  unlockScreenTimerExpired = false;
  unlockScreenTimer = SYS_TIME_CallbackRegisterMS(unlockScreenTimerCallback, 0 , 3000, SYS_TIME_SINGLE);
}

void event_TemperatureModeSingle_ButtonLockScreen_OnReleased(leButtonWidget* btn)
{
  // printf("released Lock Power\r\n");

  // check if unlock time satified
  if(unlockScreenTimerExpired)
  {
    TemperatureModeSingle_ButtonLockScreen->fn->setReleasedImage(TemperatureModeSingle_ButtonLockScreen, (leImage*)&ICON_lockOpen);
    TemperatureModeSingle_ButtonSettings->fn->setEnabled(TemperatureModeSingle_ButtonSettings, LE_TRUE);
    TemperatureModeSingle_ButtonBack->fn->setEnabled(TemperatureModeSingle_ButtonBack, LE_TRUE);
    TemperatureModeSingle_ButtonTimer->fn->setEnabled(TemperatureModeSingle_ButtonTimer, LE_TRUE);
    TemperatureModeSingle_TempSlider->fn->setEnabled(TemperatureModeSingle_TempSlider, LE_TRUE);
  }
  else
  {
    TemperatureModeSingle_ButtonSettings->fn->setEnabled(TemperatureModeSingle_ButtonSettings, LE_FALSE);
    TemperatureModeSingle_ButtonBack->fn->setEnabled(TemperatureModeSingle_ButtonBack, LE_FALSE);
    TemperatureModeSingle_ButtonTimer->fn->setEnabled(TemperatureModeSingle_ButtonTimer, LE_FALSE);
    TemperatureModeSingle_TempSlider->fn->setEnabled(TemperatureModeSingle_TempSlider, LE_FALSE);
  }
}


void event_TemperatureModeSingle_ButtonSettings_OnPressed(leButtonWidget* btn)
{
  // printf("pressed Settings Temperature\r\n");
}

void event_TemperatureModeSingle_ButtonSettings_OnReleased(leButtonWidget* btn)
{
  printf("release Settings  Temperature\r\n");
  // show next screen
  PreviousScreen = screenID_TemperatureModeSingle;
  printf("PreviousScreen: %d\r\n", PreviousScreen);
  legato_showScreen(screenID_Settings);  
}


void event_TemperatureModeSingle_ButtonBack_OnPressed(leButtonWidget* btn)
{
  EggTimerData = 0;
}

void event_TemperatureModeSingle_ButtonBack_OnReleased(leButtonWidget* btn)
{
  // printf("release Back Temperature\r\n");
  // show next screen
  legato_showScreen(screenID_SelectCookMode);
}

void event_TemperatureModeSingle_TempSlider_OnValueChanged(leCircularSliderWidget* sld, int32_t val)
{
   if(val>0)
    setTempValue = ((100-val)*3.4) + 84;
   else
       setTempValue = 84;
   //printf("Temp: %d", (int)tempValue);
   
   sprintf(cSetTempBuffer,"%d%%",setTempValue);
   setTempString.fn->setFromCStr(&setTempString, cSetTempBuffer);
   TemperatureModeSingle_LabelTemperatureSet->fn->setString(TemperatureModeSingle_LabelTemperatureSet, (leString*)&setTempString); 
    
}
/*******************************************************************************
 End of File
 */



