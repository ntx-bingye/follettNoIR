#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "configuration.h"
#include "app.h"
#include "screens/home.h"
#include "peripheral/pwm/plib_pwm.h"

// the Home screen is only scheduled to run once at Power-Up
// default cook mode is COOK_MODE_POWER
uint8_t CookMode = COOK_MODE_POWER;


static SYS_TIME_HANDLE homeScreenTimeout = SYS_TIME_HANDLE_INVALID;
static void homeScreenTimeoutCallback(uintptr_t context);

static void homeScreenTimeoutCallback(uintptr_t context)
{ // show SelectOperationaCooklMode screen
  legato_showScreen(screenID_SelectCookMode);
}


void homeScreen(void)
{
  // assign 5 second screen timer
  homeScreenTimeout = SYS_TIME_CallbackRegisterMS(homeScreenTimeoutCallback, 0 , 5000, SYS_TIME_SINGLE);
  
  PWM_ChannelDutySet(PWM_CHANNEL_2,800); // White
  PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
}


void Home_OnShow()
{
  CookMode = COOK_MODE_POWER;
  
  // Load the version into the UI
  Home_ModelWattage->fn->setString(Home_ModelWattage, (leString*)&string_MC1500);
  
}


/*******************************************************************************
 End of File
 */

