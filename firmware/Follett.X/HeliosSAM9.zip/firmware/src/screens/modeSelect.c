#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "configuration.h"
#include "app.h"
#include "peripheral/pwm/plib_pwm.h"

extern uint8_t CookMode;
extern bool frontWarmerOn;

void event_SelectCookMode_ButtonPower_OnPressed(leButtonWidget* btn)
{
   printf("pressed Power\r\n");
  SelectCookMode_ButtonTemperature->fn->setReleasedImage
    (SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsInactiveR);
}

void event_SelectCookMode_ButtonPower_OnReleased(leButtonWidget* btn)
{
   printf("released Power\r\n");
   sent=false;
           
  // show next screen
  CookMode = COOK_MODE_POWER;
  // show next screen
  legato_showScreen(screenID_PowerModeSingle);
}

void event_SelectCookMode_ButtonTemperature_OnPressed(leButtonWidget* btn)
{  
  // printf("pressed Temperature Mode\r\n");
  SelectCookMode_ButtonPower->fn->setReleasedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsInactiveL);
}

void event_SelectCookMode_ButtonTemperature_OnReleased(leButtonWidget* btn)
{
  // printf("released Temperature Mode\r\n");
  // show next screen
  CookMode = COOK_MODE_TEMP;
  legato_showScreen(screenID_TemperatureModeSingle);
}

void SelectCookMode_OnShow()
{
    frontWarmerOn = false;
    
    if(CookMode == COOK_MODE_POWER)
    {
        SelectCookMode_ButtonPower->fn->setPressedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsActiveL);
        SelectCookMode_ButtonPower->fn->setReleasedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsActiveL);
        SelectCookMode_ButtonTemperature->fn->setPressedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsActiveR);
        SelectCookMode_ButtonTemperature->fn->setReleasedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsInactiveR);
    }
    else
    {
        SelectCookMode_ButtonPower->fn->setPressedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsActiveL);
        SelectCookMode_ButtonPower->fn->setReleasedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsInactiveL);
        SelectCookMode_ButtonTemperature->fn->setPressedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsActiveR);
        SelectCookMode_ButtonTemperature->fn->setReleasedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsActiveR);
    }
    
    PWM_ChannelDutySet(PWM_CHANNEL_2,800); // White
    PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
}


/*******************************************************************************
 End of File
 */

