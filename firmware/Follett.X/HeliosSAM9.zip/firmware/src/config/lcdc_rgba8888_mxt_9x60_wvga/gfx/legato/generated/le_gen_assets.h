/*******************************************************************************
 Module for Microchip Legato Graphics Library

  Company:
    Microchip Technology Inc.

  File Name:
    le_gen_assets.h

  Summary:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.


  Description:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.

*******************************************************************************/


// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C)  Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

// DOM-IGNORE-END

#ifndef LE_GEN_ASSETS_H
#define LE_GEN_ASSETS_H

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

#include "gfx/legato/legato.h"

extern const lePalette leGlobalPalette;

/*****************************************************************************
 * Legato Graphics Image Assets
 *****************************************************************************/
/*********************************
 * Legato Image Asset
 * Name:   QuickstartDown_WVGA
 * Size:   260x120 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage QuickstartDown_WVGA;

/*********************************
 * Legato Image Asset
 * Name:   QuickstartUp_WVGA
 * Size:   260x120 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage QuickstartUp_WVGA;

/*********************************
 * Legato Image Asset
 * Name:   mchpLogo_light
 * Size:   152x40 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage mchpLogo_light;

/*********************************
 * Legato Image Asset
 * Name:   closex
 * Size:   27x27 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage closex;

/*********************************
 * Legato Image Asset
 * Name:   cm
 * Size:   28x28 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage cm;

/*********************************
 * Legato Image Asset
 * Name:   downcaret
 * Size:   23x15 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage downcaret;

/*********************************
 * Legato Image Asset
 * Name:   gear
 * Size:   27x26 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage gear;

/*********************************
 * Legato Image Asset
 * Name:   thermometer
 * Size:   12x25 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage thermometer;

/*********************************
 * Legato Image Asset
 * Name:   warning
 * Size:   20x21 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage warning;

/*********************************
 * Legato Image Asset
 * Name:   Icon_battery
 * Size:   14x25 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage Icon_battery;

/*********************************
 * Legato Image Asset
 * Name:   ICON_battery_critical
 * Size:   14x25 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_battery_critical;

/*********************************
 * Legato Image Asset
 * Name:   ICON_brightness
 * Size:   26x26 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_brightness;

/*********************************
 * Legato Image Asset
 * Name:   ICON_contrast
 * Size:   26x26 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_contrast;

/*********************************
 * Legato Image Asset
 * Name:   ICON_CookTek_LOGO
 * Size:   222x35 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_CookTek_LOGO;

/*********************************
 * Legato Image Asset
 * Name:   ICON_downActive
 * Size:   21x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_downActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_downInactive
 * Size:   21x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_downInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_error
 * Size:   207x49 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_error;

/*********************************
 * Legato Image Asset
 * Name:   ICON_exitActive
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_exitActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_exitInactive
 * Size:   24x24 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_exitInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_goBackActive
 * Size:   24x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_goBackActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_goBackInactive
 * Size:   24x20 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_goBackInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_back
 * Size:   87x40 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_back;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_back_icon
 * Size:   87x40 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_back_icon;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_number
 * Size:   40x40 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_number;

/*********************************
 * Legato Image Asset
 * Name:   ICON_lockClosed
 * Size:   22x28 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_lockClosed;

/*********************************
 * Legato Image Asset
 * Name:   ICON_lockOpen
 * Size:   22x28 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_lockOpen;

/*********************************
 * Legato Image Asset
 * Name:   ICON_minusActive
 * Size:   62x41 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_minusActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_minusInactive
 * Size:   56x41 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_minusInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_passcode_box
 * Size:   304x45 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_passcode_box;

/*********************************
 * Legato Image Asset
 * Name:   ICON_plusActive
 * Size:   62x41 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_plusActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_plusInactive
 * Size:   62x41 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_plusInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsActive
 * Size:   115x48 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsInactive
 * Size:   109x44 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_thermometer
 * Size:   26x26 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_thermometer;

/*********************************
 * Legato Image Asset
 * Name:   ICON_timerActive
 * Size:   26x28 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_timerActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_timerInActive
 * Size:   26x28 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_timerInActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_upActive
 * Size:   21x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_upActive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_upInactive
 * Size:   21x14 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_upInactive;

/*********************************
 * Legato Image Asset
 * Name:   ICON_warning
 * Size:   207x49 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_warning;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_del
 * Size:   70x70 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_del;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_enter
 * Size:   70x70 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_enter;

/*********************************
 * Legato Image Asset
 * Name:   ICON_keypad_number2
 * Size:   70x70 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_keypad_number2;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsActiveL
 * Size:   145x48 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsActiveL;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsActiveR
 * Size:   145x48 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsActiveR;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsInactiveL
 * Size:   145x44 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsInactiveL;

/*********************************
 * Legato Image Asset
 * Name:   ICON_settingsInactiveR
 * Size:   145x44 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_settingsInactiveR;

/*********************************
 * Legato Image Asset
 * Name:   EmptyCircle
 * Size:   245x245 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage EmptyCircle;

/*********************************
 * Legato Image Asset
 * Name:   EmptyCircle2
 * Size:   245x245 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage EmptyCircle2;

/*********************************
 * Legato Image Asset
 * Name:   ICON_Red_Circle2
 * Size:   254x250 pixels
 * Type:   RGB Data
 * Format: RGBA_8888
 ***********************************/
extern leImage ICON_Red_Circle2;

/*****************************************************************************
 * Legato Graphics Font Assets
 *****************************************************************************/
/*********************************
 * Legato Font Asset
 * Name:         NotoSans_48
 * Height:       21
 * Baseline:     0
 * Style:        Antialias
 * Glyph Count:  0
 * Range Count:  0
 * Glyph Ranges: ***********************************/
extern leRasterFont NotoSans_48;

/*********************************
 * Legato Font Asset
 * Name:         NotoSans0
 * Height:       21
 * Baseline:     9
 * Style:        Plain
 * Glyph Count:  95
 * Range Count:  19
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont NotoSans0;

/*********************************
 * Legato Font Asset
 * Name:         Font0
 * Height:       37
 * Baseline:     9
 * Style:        Plain
 * Glyph Count:  95
 * Range Count:  1
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont Font0;

/*********************************
 * Legato Font Asset
 * Name:         Roboto
 * Height:       37
 * Baseline:     9
 * Style:        Plain
 * Glyph Count:  95
 * Range Count:  1
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont Roboto;

/*********************************
 * Legato Font Asset
 * Name:         RobotoMed11
 * Height:       37
 * Baseline:     12
 * Style:        Plain
 * Glyph Count:  224
 * Range Count:  1
 * Glyph Ranges: 0x20-0xFF
***********************************/
extern leRasterFont RobotoMed11;

/*********************************
 * Legato Font Asset
 * Name:         RobotoReg14
 * Height:       37
 * Baseline:     14
 * Style:        Plain
 * Glyph Count:  224
 * Range Count:  14
 * Glyph Ranges: 0x20-0xFF
***********************************/
extern leRasterFont RobotoReg14;

/*********************************
 * Legato Font Asset
 * Name:         RobotoReg20
 * Height:       37
 * Baseline:     19
 * Style:        Plain
 * Glyph Count:  225
 * Range Count:  13
 * Glyph Ranges: 0xA
                 0x20-0xFF
***********************************/
extern leRasterFont RobotoReg20;

/*********************************
 * Legato Font Asset
 * Name:         RobotoReg48
 * Height:       37
 * Baseline:     46
 * Style:        Plain
 * Glyph Count:  224
 * Range Count:  8
 * Glyph Ranges: 0x20-0xFF
***********************************/
extern leRasterFont RobotoReg48;

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   98
 *****************************************************************************/

// language IDs
#define language_English    0

// string IDs
#define stringID_Keypad3    0
#define stringID_Error01b    1
#define stringID_HomeModelValue    2
#define stringID_Wattage3000    3
#define stringID_Error08a    4
#define stringID_MaximumWattage    5
#define stringID_FirmwareVersionInitial    6
#define stringID_TimerMinutesRemaining    7
#define stringID_SelectOneToProceed    8
#define stringID_VersionHOB2Value    9
#define stringID_Wattage3500    10
#define stringID_TemperatureScale    11
#define stringID_Keypad9    12
#define stringID_LineVoltage240    13
#define stringID_LineVoltageMeasured    14
#define stringID_LineFrequency    15
#define stringID_Error02    16
#define stringID_Error01    17
#define stringID_MC1800    18
#define stringID_TopGlassTemperature80F    19
#define stringID_Keypad1    20
#define stringID_ServiceTechnicianSettings    21
#define stringID_Error07    22
#define stringID_MC3500    23
#define stringID_Percent    24
#define stringID_TemperatureFahrenheit    25
#define stringID_MC2000    26
#define stringID_FirmwareVersionsView    27
#define stringID_Disable    28
#define stringID_ErrorCodeCounts    29
#define stringID_Error16a    30
#define stringID_WattageCalculated    31
#define stringID_Error03a    32
#define stringID_MC2500    33
#define stringID_Wattage1800    34
#define stringID_Error16    35
#define stringID_Keypad5    36
#define stringID_PowerValue    37
#define stringID_Error08    38
#define stringID_TemperatureCurrent    39
#define stringID_LineVoltageCalibration    40
#define stringID_Keypad6    41
#define stringID_Error04a    42
#define stringID_Keypad4    43
#define stringID_SettingsMenu    44
#define stringID_ServiceAgentsEnterPasscode    45
#define stringID_VersionUIValue    46
#define stringID_Keypad7    47
#define stringID_Error03    48
#define stringID_Power    49
#define stringID_Warning01    50
#define stringID_TimerEnterMinutes    51
#define stringID_Error07a    52
#define stringID_FirmwareVersionHOB2    53
#define stringID_WattageSelection    54
#define stringID_Enable    55
#define stringID_ErrorCodeCount255    56
#define stringID_OtherSettings    57
#define stringID_MC1500    58
#define stringID_FirmwareVersions    59
#define stringID_Error06    60
#define stringID_Wattage2000    61
#define stringID_LineVoltage246    62
#define stringID_TemperatureCentigrade    63
#define stringID_ErrorLogReset    64
#define stringID_Error02a    65
#define stringID_ServiceAgentPassCodeFail    66
#define stringID_LineVoltage    67
#define stringID_Wattage1500    68
#define stringID_WattageMeasured2200    69
#define stringID_TopGlassTemperature    70
#define stringID_LineVoltageActual    71
#define stringID_ScreenBrightness    72
#define stringID_Keypad2    73
#define stringID_FirmwareVersionHOB1    74
#define stringID_TemperatureSet    75
#define stringID_Temperature    76
#define stringID_Error04    77
#define stringID_Error06a    78
#define stringID_FirmwareVersionNotEquipped    79
#define stringID_String    80
#define stringID_Keypad0    81
#define stringID_LineFrequency60Hz    82
#define stringID_TimerMinutes    83
#define stringID_CurrentLimitMaximum    84
#define stringID_Reset    85
#define stringID_ErrorLogView    86
#define stringID_LineVolts240    87
#define stringID_MC3000    88
#define stringID_PerformanceDataView    89
#define stringID_FirmwareVersionUI    90
#define stringID_Model    91
#define stringID_Wattage2500    92
#define stringID_TemperatureReached    93
#define stringID_ErrorCodesDestriptions    94
#define stringID_VersionHOB1Value    95
#define stringID_keypad8    96
#define stringID_Error01a    97

extern const leStringTable stringTable;


// string list
extern leTableString string_Keypad3;
extern leTableString string_Error01b;
extern leTableString string_HomeModelValue;
extern leTableString string_Wattage3000;
extern leTableString string_Error08a;
extern leTableString string_MaximumWattage;
extern leTableString string_FirmwareVersionInitial;
extern leTableString string_TimerMinutesRemaining;
extern leTableString string_SelectOneToProceed;
extern leTableString string_VersionHOB2Value;
extern leTableString string_Wattage3500;
extern leTableString string_TemperatureScale;
extern leTableString string_Keypad9;
extern leTableString string_LineVoltage240;
extern leTableString string_LineVoltageMeasured;
extern leTableString string_LineFrequency;
extern leTableString string_Error02;
extern leTableString string_Error01;
extern leTableString string_MC1800;
extern leTableString string_TopGlassTemperature80F;
extern leTableString string_Keypad1;
extern leTableString string_ServiceTechnicianSettings;
extern leTableString string_Error07;
extern leTableString string_MC3500;
extern leTableString string_Percent;
extern leTableString string_TemperatureFahrenheit;
extern leTableString string_MC2000;
extern leTableString string_FirmwareVersionsView;
extern leTableString string_Disable;
extern leTableString string_ErrorCodeCounts;
extern leTableString string_Error16a;
extern leTableString string_WattageCalculated;
extern leTableString string_Error03a;
extern leTableString string_MC2500;
extern leTableString string_Wattage1800;
extern leTableString string_Error16;
extern leTableString string_Keypad5;
extern leTableString string_PowerValue;
extern leTableString string_Error08;
extern leTableString string_TemperatureCurrent;
extern leTableString string_LineVoltageCalibration;
extern leTableString string_Keypad6;
extern leTableString string_Error04a;
extern leTableString string_Keypad4;
extern leTableString string_SettingsMenu;
extern leTableString string_ServiceAgentsEnterPasscode;
extern leTableString string_VersionUIValue;
extern leTableString string_Keypad7;
extern leTableString string_Error03;
extern leTableString string_Power;
extern leTableString string_Warning01;
extern leTableString string_TimerEnterMinutes;
extern leTableString string_Error07a;
extern leTableString string_FirmwareVersionHOB2;
extern leTableString string_WattageSelection;
extern leTableString string_Enable;
extern leTableString string_ErrorCodeCount255;
extern leTableString string_OtherSettings;
extern leTableString string_MC1500;
extern leTableString string_FirmwareVersions;
extern leTableString string_Error06;
extern leTableString string_Wattage2000;
extern leTableString string_LineVoltage246;
extern leTableString string_TemperatureCentigrade;
extern leTableString string_ErrorLogReset;
extern leTableString string_Error02a;
extern leTableString string_ServiceAgentPassCodeFail;
extern leTableString string_LineVoltage;
extern leTableString string_Wattage1500;
extern leTableString string_WattageMeasured2200;
extern leTableString string_TopGlassTemperature;
extern leTableString string_LineVoltageActual;
extern leTableString string_ScreenBrightness;
extern leTableString string_Keypad2;
extern leTableString string_FirmwareVersionHOB1;
extern leTableString string_TemperatureSet;
extern leTableString string_Temperature;
extern leTableString string_Error04;
extern leTableString string_Error06a;
extern leTableString string_FirmwareVersionNotEquipped;
extern leTableString string_String;
extern leTableString string_Keypad0;
extern leTableString string_LineFrequency60Hz;
extern leTableString string_TimerMinutes;
extern leTableString string_CurrentLimitMaximum;
extern leTableString string_Reset;
extern leTableString string_ErrorLogView;
extern leTableString string_LineVolts240;
extern leTableString string_MC3000;
extern leTableString string_PerformanceDataView;
extern leTableString string_FirmwareVersionUI;
extern leTableString string_Model;
extern leTableString string_Wattage2500;
extern leTableString string_TemperatureReached;
extern leTableString string_ErrorCodesDestriptions;
extern leTableString string_VersionHOB1Value;
extern leTableString string_keypad8;
extern leTableString string_Error01a;

void initializeStrings(void);
//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* LE_GEN_ASSETS_H */
