#include "gfx/legato/generated/screen/le_gen_screen_SelectCookMode.h"

// screen member widget declarations
leWidget* root0;

leWidget* SelectCookMode_Layer0_FillPanel;
leLabelWidget* SelectCookMode_LabelSelectOne;
leButtonWidget* SelectCookMode_ButtonPower;
leButtonWidget* SelectCookMode_ButtonTemperature;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_SelectCookMode(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_SelectCookMode(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    SelectCookMode_Layer0_FillPanel = leWidget_New();
    SelectCookMode_Layer0_FillPanel->fn->setPosition(SelectCookMode_Layer0_FillPanel, 0, 0);
    SelectCookMode_Layer0_FillPanel->fn->setSize(SelectCookMode_Layer0_FillPanel, 480, 272);
    SelectCookMode_Layer0_FillPanel->fn->setScheme(SelectCookMode_Layer0_FillPanel, &BackgroundScheme);
    SelectCookMode_Layer0_FillPanel->fn->setHAlignment(SelectCookMode_Layer0_FillPanel, LE_HALIGN_RIGHT);
    root0->fn->addChild(root0, (leWidget*)SelectCookMode_Layer0_FillPanel);

    SelectCookMode_LabelSelectOne = leLabelWidget_New();
    SelectCookMode_LabelSelectOne->fn->setPosition(SelectCookMode_LabelSelectOne, 1, 176);
    SelectCookMode_LabelSelectOne->fn->setSize(SelectCookMode_LabelSelectOne, 478, 60);
    SelectCookMode_LabelSelectOne->fn->setScheme(SelectCookMode_LabelSelectOne, &BackgroundScheme);
    SelectCookMode_LabelSelectOne->fn->setHAlignment(SelectCookMode_LabelSelectOne, LE_HALIGN_CENTER);
    SelectCookMode_LabelSelectOne->fn->setString(SelectCookMode_LabelSelectOne, (leString*)&string_SelectOneToProceed);
    root0->fn->addChild(root0, (leWidget*)SelectCookMode_LabelSelectOne);

    SelectCookMode_ButtonPower = leButtonWidget_New();
    SelectCookMode_ButtonPower->fn->setPosition(SelectCookMode_ButtonPower, 86, 105);
    SelectCookMode_ButtonPower->fn->setSize(SelectCookMode_ButtonPower, 145, 60);
    SelectCookMode_ButtonPower->fn->setScheme(SelectCookMode_ButtonPower, &BackgroundScheme);
    SelectCookMode_ButtonPower->fn->setBackgroundType(SelectCookMode_ButtonPower, LE_WIDGET_BACKGROUND_NONE);
    SelectCookMode_ButtonPower->fn->setBorderType(SelectCookMode_ButtonPower, LE_WIDGET_BORDER_NONE);
    SelectCookMode_ButtonPower->fn->setMargins(SelectCookMode_ButtonPower, 4, 4, 0, 4);
    SelectCookMode_ButtonPower->fn->setString(SelectCookMode_ButtonPower, (leString*)&string_Power);
    SelectCookMode_ButtonPower->fn->setPressedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsActiveL);
    SelectCookMode_ButtonPower->fn->setReleasedImage(SelectCookMode_ButtonPower, (leImage*)&ICON_settingsActiveL);
    SelectCookMode_ButtonPower->fn->setImagePosition(SelectCookMode_ButtonPower, LE_RELATIVE_POSITION_BEHIND);
    SelectCookMode_ButtonPower->fn->setPressedEventCallback(SelectCookMode_ButtonPower, event_SelectCookMode_ButtonPower_OnPressed);
    SelectCookMode_ButtonPower->fn->setReleasedEventCallback(SelectCookMode_ButtonPower, event_SelectCookMode_ButtonPower_OnReleased);
    root0->fn->addChild(root0, (leWidget*)SelectCookMode_ButtonPower);

    SelectCookMode_ButtonTemperature = leButtonWidget_New();
    SelectCookMode_ButtonTemperature->fn->setPosition(SelectCookMode_ButtonTemperature, 230, 105);
    SelectCookMode_ButtonTemperature->fn->setSize(SelectCookMode_ButtonTemperature, 145, 60);
    SelectCookMode_ButtonTemperature->fn->setScheme(SelectCookMode_ButtonTemperature, &BackgroundScheme);
    SelectCookMode_ButtonTemperature->fn->setBorderType(SelectCookMode_ButtonTemperature, LE_WIDGET_BORDER_NONE);
    SelectCookMode_ButtonTemperature->fn->setMargins(SelectCookMode_ButtonTemperature, 0, 4, 4, 4);
    SelectCookMode_ButtonTemperature->fn->setString(SelectCookMode_ButtonTemperature, (leString*)&string_Temperature);
    SelectCookMode_ButtonTemperature->fn->setPressedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsActiveR);
    SelectCookMode_ButtonTemperature->fn->setReleasedImage(SelectCookMode_ButtonTemperature, (leImage*)&ICON_settingsActiveR);
    SelectCookMode_ButtonTemperature->fn->setImagePosition(SelectCookMode_ButtonTemperature, LE_RELATIVE_POSITION_BEHIND);
    SelectCookMode_ButtonTemperature->fn->setPressedEventCallback(SelectCookMode_ButtonTemperature, event_SelectCookMode_ButtonTemperature_OnPressed);
    SelectCookMode_ButtonTemperature->fn->setReleasedEventCallback(SelectCookMode_ButtonTemperature, event_SelectCookMode_ButtonTemperature_OnReleased);
    root0->fn->addChild(root0, (leWidget*)SelectCookMode_ButtonTemperature);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    SelectCookMode_OnShow(); // raise event

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_SelectCookMode(void)
{
}

void screenHide_SelectCookMode(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    SelectCookMode_Layer0_FillPanel = NULL;
    SelectCookMode_LabelSelectOne = NULL;
    SelectCookMode_ButtonPower = NULL;
    SelectCookMode_ButtonTemperature = NULL;


    showing = LE_FALSE;
}

void screenDestroy_SelectCookMode(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_SelectCookMode(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

