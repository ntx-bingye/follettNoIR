#include "gfx/legato/generated/screen/le_gen_screen_TimerInit.h"

// screen member widget declarations
leWidget* root0;

leWidget* TimerInit_PanelWidget0;
leButtonWidget* TimerInit_ButtonExit;
leLabelWidget* TimerInit_LabelTimerUserNote;
leTextFieldWidget* TimerInit_TextFieldTimerMinutes;
leWidget* TimerInit_PanelKeypadBack;
leButtonWidget* TimerInit_ButtonKey0;
leButtonWidget* TimerInit_ButtonKey1;
leButtonWidget* TimerInit_ButtonKey2;
leButtonWidget* TimerInit_ButtonKey3;
leButtonWidget* TimerInit_ButtonKey4;
leButtonWidget* TimerInit_ButtonKey5;
leButtonWidget* TimerInit_ButtonKey6;
leButtonWidget* TimerInit_ButtonKey7;
leButtonWidget* TimerInit_ButtonKey8;
leButtonWidget* TimerInit_ButtonKey9;
leButtonWidget* TimerInit_ButtonKeyBackSpace;
leButtonWidget* TimerInit_ButtonKeyEnter;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_TimerInit(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_TimerInit(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    TimerInit_PanelWidget0 = leWidget_New();
    TimerInit_PanelWidget0->fn->setPosition(TimerInit_PanelWidget0, 0, 0);
    TimerInit_PanelWidget0->fn->setSize(TimerInit_PanelWidget0, 480, 272);
    TimerInit_PanelWidget0->fn->setScheme(TimerInit_PanelWidget0, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)TimerInit_PanelWidget0);

    TimerInit_ButtonExit = leButtonWidget_New();
    TimerInit_ButtonExit->fn->setPosition(TimerInit_ButtonExit, 431, 4);
    TimerInit_ButtonExit->fn->setSize(TimerInit_ButtonExit, 45, 45);
    TimerInit_ButtonExit->fn->setScheme(TimerInit_ButtonExit, &defaultScheme);
    TimerInit_ButtonExit->fn->setBackgroundType(TimerInit_ButtonExit, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonExit->fn->setBorderType(TimerInit_ButtonExit, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonExit->fn->setPressedImage(TimerInit_ButtonExit, (leImage*)&ICON_exitActive);
    TimerInit_ButtonExit->fn->setReleasedImage(TimerInit_ButtonExit, (leImage*)&ICON_exitActive);
    TimerInit_ButtonExit->fn->setPressedEventCallback(TimerInit_ButtonExit, event_TimerInit_ButtonExit_OnPressed);
    TimerInit_ButtonExit->fn->setReleasedEventCallback(TimerInit_ButtonExit, event_TimerInit_ButtonExit_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonExit);

    TimerInit_LabelTimerUserNote = leLabelWidget_New();
    TimerInit_LabelTimerUserNote->fn->setPosition(TimerInit_LabelTimerUserNote, 160, 29);
    TimerInit_LabelTimerUserNote->fn->setSize(TimerInit_LabelTimerUserNote, 160, 25);
    TimerInit_LabelTimerUserNote->fn->setScheme(TimerInit_LabelTimerUserNote, &BackgroundScheme);
    TimerInit_LabelTimerUserNote->fn->setBackgroundType(TimerInit_LabelTimerUserNote, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_LabelTimerUserNote->fn->setString(TimerInit_LabelTimerUserNote, (leString*)&string_TimerEnterMinutes);
    root0->fn->addChild(root0, (leWidget*)TimerInit_LabelTimerUserNote);

    TimerInit_TextFieldTimerMinutes = leTextFieldWidget_New();
    TimerInit_TextFieldTimerMinutes->fn->setPosition(TimerInit_TextFieldTimerMinutes, 215, 68);
    TimerInit_TextFieldTimerMinutes->fn->setSize(TimerInit_TextFieldTimerMinutes, 50, 25);
    TimerInit_TextFieldTimerMinutes->fn->setScheme(TimerInit_TextFieldTimerMinutes, &LayerScheme);
    TimerInit_TextFieldTimerMinutes->fn->setBorderType(TimerInit_TextFieldTimerMinutes, LE_WIDGET_BORDER_NONE);
    TimerInit_TextFieldTimerMinutes->fn->setHAlignment(TimerInit_TextFieldTimerMinutes, LE_HALIGN_LEFT);
    TimerInit_TextFieldTimerMinutes->fn->setMargins(TimerInit_TextFieldTimerMinutes, 15, 4, 4, 4);
    TimerInit_TextFieldTimerMinutes->fn->setString(TimerInit_TextFieldTimerMinutes, (leString*)&string_TimerMinutes);
    TimerInit_TextFieldTimerMinutes->fn->setFont(TimerInit_TextFieldTimerMinutes, (leFont*)&NotoSans0);
    root0->fn->addChild(root0, (leWidget*)TimerInit_TextFieldTimerMinutes);

    TimerInit_PanelKeypadBack = leWidget_New();
    TimerInit_PanelKeypadBack->fn->setPosition(TimerInit_PanelKeypadBack, 0, 108);
    TimerInit_PanelKeypadBack->fn->setSize(TimerInit_PanelKeypadBack, 480, 166);
    TimerInit_PanelKeypadBack->fn->setScheme(TimerInit_PanelKeypadBack, &KeypadBack);
    root0->fn->addChild(root0, (leWidget*)TimerInit_PanelKeypadBack);

    TimerInit_ButtonKey0 = leButtonWidget_New();
    TimerInit_ButtonKey0->fn->setPosition(TimerInit_ButtonKey0, 8, 114);
    TimerInit_ButtonKey0->fn->setSize(TimerInit_ButtonKey0, 74, 74);
    TimerInit_ButtonKey0->fn->setScheme(TimerInit_ButtonKey0, &LayerScheme);
    TimerInit_ButtonKey0->fn->setBackgroundType(TimerInit_ButtonKey0, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey0->fn->setBorderType(TimerInit_ButtonKey0, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey0->fn->setString(TimerInit_ButtonKey0, (leString*)&string_Keypad0);
    TimerInit_ButtonKey0->fn->setPressedImage(TimerInit_ButtonKey0, (leImage*)&ICON_keypad_number);
    TimerInit_ButtonKey0->fn->setReleasedImage(TimerInit_ButtonKey0, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey0->fn->setImagePosition(TimerInit_ButtonKey0, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey0->fn->setPressedEventCallback(TimerInit_ButtonKey0, event_TimerInit_ButtonKey0_OnPressed);
    TimerInit_ButtonKey0->fn->setReleasedEventCallback(TimerInit_ButtonKey0, event_TimerInit_ButtonKey0_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey0);

    TimerInit_ButtonKey1 = leButtonWidget_New();
    TimerInit_ButtonKey1->fn->setPosition(TimerInit_ButtonKey1, 86, 114);
    TimerInit_ButtonKey1->fn->setSize(TimerInit_ButtonKey1, 74, 74);
    TimerInit_ButtonKey1->fn->setScheme(TimerInit_ButtonKey1, &LayerScheme);
    TimerInit_ButtonKey1->fn->setBackgroundType(TimerInit_ButtonKey1, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey1->fn->setBorderType(TimerInit_ButtonKey1, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey1->fn->setString(TimerInit_ButtonKey1, (leString*)&string_Keypad1);
    TimerInit_ButtonKey1->fn->setPressedImage(TimerInit_ButtonKey1, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey1->fn->setReleasedImage(TimerInit_ButtonKey1, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey1->fn->setImagePosition(TimerInit_ButtonKey1, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey1->fn->setPressedEventCallback(TimerInit_ButtonKey1, event_TimerInit_ButtonKey1_OnPressed);
    TimerInit_ButtonKey1->fn->setReleasedEventCallback(TimerInit_ButtonKey1, event_TimerInit_ButtonKey1_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey1);

    TimerInit_ButtonKey2 = leButtonWidget_New();
    TimerInit_ButtonKey2->fn->setPosition(TimerInit_ButtonKey2, 164, 114);
    TimerInit_ButtonKey2->fn->setSize(TimerInit_ButtonKey2, 74, 74);
    TimerInit_ButtonKey2->fn->setScheme(TimerInit_ButtonKey2, &LayerScheme);
    TimerInit_ButtonKey2->fn->setBackgroundType(TimerInit_ButtonKey2, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey2->fn->setBorderType(TimerInit_ButtonKey2, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey2->fn->setString(TimerInit_ButtonKey2, (leString*)&string_Keypad2);
    TimerInit_ButtonKey2->fn->setPressedImage(TimerInit_ButtonKey2, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey2->fn->setReleasedImage(TimerInit_ButtonKey2, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey2->fn->setImagePosition(TimerInit_ButtonKey2, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey2->fn->setPressedEventCallback(TimerInit_ButtonKey2, event_TimerInit_ButtonKey2_OnPressed);
    TimerInit_ButtonKey2->fn->setReleasedEventCallback(TimerInit_ButtonKey2, event_TimerInit_ButtonKey2_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey2);

    TimerInit_ButtonKey3 = leButtonWidget_New();
    TimerInit_ButtonKey3->fn->setPosition(TimerInit_ButtonKey3, 242, 114);
    TimerInit_ButtonKey3->fn->setSize(TimerInit_ButtonKey3, 74, 74);
    TimerInit_ButtonKey3->fn->setScheme(TimerInit_ButtonKey3, &LayerScheme);
    TimerInit_ButtonKey3->fn->setBackgroundType(TimerInit_ButtonKey3, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey3->fn->setBorderType(TimerInit_ButtonKey3, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey3->fn->setString(TimerInit_ButtonKey3, (leString*)&string_Keypad3);
    TimerInit_ButtonKey3->fn->setPressedImage(TimerInit_ButtonKey3, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey3->fn->setReleasedImage(TimerInit_ButtonKey3, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey3->fn->setImagePosition(TimerInit_ButtonKey3, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey3->fn->setPressedEventCallback(TimerInit_ButtonKey3, event_TimerInit_ButtonKey3_OnPressed);
    TimerInit_ButtonKey3->fn->setReleasedEventCallback(TimerInit_ButtonKey3, event_TimerInit_ButtonKey3_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey3);

    TimerInit_ButtonKey4 = leButtonWidget_New();
    TimerInit_ButtonKey4->fn->setPosition(TimerInit_ButtonKey4, 320, 114);
    TimerInit_ButtonKey4->fn->setSize(TimerInit_ButtonKey4, 74, 74);
    TimerInit_ButtonKey4->fn->setScheme(TimerInit_ButtonKey4, &LayerScheme);
    TimerInit_ButtonKey4->fn->setBackgroundType(TimerInit_ButtonKey4, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey4->fn->setBorderType(TimerInit_ButtonKey4, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey4->fn->setString(TimerInit_ButtonKey4, (leString*)&string_Keypad4);
    TimerInit_ButtonKey4->fn->setPressedImage(TimerInit_ButtonKey4, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey4->fn->setReleasedImage(TimerInit_ButtonKey4, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey4->fn->setImagePosition(TimerInit_ButtonKey4, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey4->fn->setPressedEventCallback(TimerInit_ButtonKey4, event_TimerInit_ButtonKey4_OnPressed);
    TimerInit_ButtonKey4->fn->setReleasedEventCallback(TimerInit_ButtonKey4, event_TimerInit_ButtonKey4_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey4);

    TimerInit_ButtonKey5 = leButtonWidget_New();
    TimerInit_ButtonKey5->fn->setPosition(TimerInit_ButtonKey5, 398, 114);
    TimerInit_ButtonKey5->fn->setSize(TimerInit_ButtonKey5, 74, 74);
    TimerInit_ButtonKey5->fn->setScheme(TimerInit_ButtonKey5, &LayerScheme);
    TimerInit_ButtonKey5->fn->setBackgroundType(TimerInit_ButtonKey5, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey5->fn->setBorderType(TimerInit_ButtonKey5, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey5->fn->setString(TimerInit_ButtonKey5, (leString*)&string_Keypad5);
    TimerInit_ButtonKey5->fn->setPressedImage(TimerInit_ButtonKey5, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey5->fn->setReleasedImage(TimerInit_ButtonKey5, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey5->fn->setImagePosition(TimerInit_ButtonKey5, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey5->fn->setPressedEventCallback(TimerInit_ButtonKey5, event_TimerInit_ButtonKey5_OnPressed);
    TimerInit_ButtonKey5->fn->setReleasedEventCallback(TimerInit_ButtonKey5, event_TimerInit_ButtonKey5_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey5);

    TimerInit_ButtonKey6 = leButtonWidget_New();
    TimerInit_ButtonKey6->fn->setPosition(TimerInit_ButtonKey6, 8, 191);
    TimerInit_ButtonKey6->fn->setSize(TimerInit_ButtonKey6, 74, 74);
    TimerInit_ButtonKey6->fn->setScheme(TimerInit_ButtonKey6, &LayerScheme);
    TimerInit_ButtonKey6->fn->setBackgroundType(TimerInit_ButtonKey6, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey6->fn->setBorderType(TimerInit_ButtonKey6, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey6->fn->setString(TimerInit_ButtonKey6, (leString*)&string_Keypad6);
    TimerInit_ButtonKey6->fn->setPressedImage(TimerInit_ButtonKey6, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey6->fn->setReleasedImage(TimerInit_ButtonKey6, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey6->fn->setImagePosition(TimerInit_ButtonKey6, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey6->fn->setPressedEventCallback(TimerInit_ButtonKey6, event_TimerInit_ButtonKey6_OnPressed);
    TimerInit_ButtonKey6->fn->setReleasedEventCallback(TimerInit_ButtonKey6, event_TimerInit_ButtonKey6_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey6);

    TimerInit_ButtonKey7 = leButtonWidget_New();
    TimerInit_ButtonKey7->fn->setPosition(TimerInit_ButtonKey7, 86, 191);
    TimerInit_ButtonKey7->fn->setSize(TimerInit_ButtonKey7, 74, 74);
    TimerInit_ButtonKey7->fn->setScheme(TimerInit_ButtonKey7, &LayerScheme);
    TimerInit_ButtonKey7->fn->setBackgroundType(TimerInit_ButtonKey7, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey7->fn->setBorderType(TimerInit_ButtonKey7, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey7->fn->setString(TimerInit_ButtonKey7, (leString*)&string_Keypad7);
    TimerInit_ButtonKey7->fn->setPressedImage(TimerInit_ButtonKey7, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey7->fn->setReleasedImage(TimerInit_ButtonKey7, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey7->fn->setImagePosition(TimerInit_ButtonKey7, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey7->fn->setPressedEventCallback(TimerInit_ButtonKey7, event_TimerInit_ButtonKey7_OnPressed);
    TimerInit_ButtonKey7->fn->setReleasedEventCallback(TimerInit_ButtonKey7, event_TimerInit_ButtonKey7_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey7);

    TimerInit_ButtonKey8 = leButtonWidget_New();
    TimerInit_ButtonKey8->fn->setPosition(TimerInit_ButtonKey8, 164, 191);
    TimerInit_ButtonKey8->fn->setSize(TimerInit_ButtonKey8, 74, 74);
    TimerInit_ButtonKey8->fn->setScheme(TimerInit_ButtonKey8, &LayerScheme);
    TimerInit_ButtonKey8->fn->setBackgroundType(TimerInit_ButtonKey8, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey8->fn->setBorderType(TimerInit_ButtonKey8, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey8->fn->setString(TimerInit_ButtonKey8, (leString*)&string_keypad8);
    TimerInit_ButtonKey8->fn->setPressedImage(TimerInit_ButtonKey8, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey8->fn->setReleasedImage(TimerInit_ButtonKey8, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey8->fn->setImagePosition(TimerInit_ButtonKey8, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey8->fn->setPressedEventCallback(TimerInit_ButtonKey8, event_TimerInit_ButtonKey8_OnPressed);
    TimerInit_ButtonKey8->fn->setReleasedEventCallback(TimerInit_ButtonKey8, event_TimerInit_ButtonKey8_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey8);

    TimerInit_ButtonKey9 = leButtonWidget_New();
    TimerInit_ButtonKey9->fn->setPosition(TimerInit_ButtonKey9, 242, 191);
    TimerInit_ButtonKey9->fn->setSize(TimerInit_ButtonKey9, 74, 74);
    TimerInit_ButtonKey9->fn->setScheme(TimerInit_ButtonKey9, &LayerScheme);
    TimerInit_ButtonKey9->fn->setBackgroundType(TimerInit_ButtonKey9, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKey9->fn->setBorderType(TimerInit_ButtonKey9, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKey9->fn->setString(TimerInit_ButtonKey9, (leString*)&string_Keypad9);
    TimerInit_ButtonKey9->fn->setPressedImage(TimerInit_ButtonKey9, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey9->fn->setReleasedImage(TimerInit_ButtonKey9, (leImage*)&ICON_keypad_number2);
    TimerInit_ButtonKey9->fn->setImagePosition(TimerInit_ButtonKey9, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKey9->fn->setPressedEventCallback(TimerInit_ButtonKey9, event_TimerInit_ButtonKey9_OnPressed);
    TimerInit_ButtonKey9->fn->setReleasedEventCallback(TimerInit_ButtonKey9, event_TimerInit_ButtonKey9_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKey9);

    TimerInit_ButtonKeyBackSpace = leButtonWidget_New();
    TimerInit_ButtonKeyBackSpace->fn->setPosition(TimerInit_ButtonKeyBackSpace, 320, 191);
    TimerInit_ButtonKeyBackSpace->fn->setSize(TimerInit_ButtonKeyBackSpace, 74, 74);
    TimerInit_ButtonKeyBackSpace->fn->setScheme(TimerInit_ButtonKeyBackSpace, &LayerScheme);
    TimerInit_ButtonKeyBackSpace->fn->setBackgroundType(TimerInit_ButtonKeyBackSpace, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKeyBackSpace->fn->setBorderType(TimerInit_ButtonKeyBackSpace, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKeyBackSpace->fn->setPressedImage(TimerInit_ButtonKeyBackSpace, (leImage*)&ICON_keypad_del);
    TimerInit_ButtonKeyBackSpace->fn->setReleasedImage(TimerInit_ButtonKeyBackSpace, (leImage*)&ICON_keypad_del);
    TimerInit_ButtonKeyBackSpace->fn->setImagePosition(TimerInit_ButtonKeyBackSpace, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKeyBackSpace->fn->setPressedEventCallback(TimerInit_ButtonKeyBackSpace, event_TimerInit_ButtonKeyBackSpace_OnPressed);
    TimerInit_ButtonKeyBackSpace->fn->setReleasedEventCallback(TimerInit_ButtonKeyBackSpace, event_TimerInit_ButtonKeyBackSpace_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKeyBackSpace);

    TimerInit_ButtonKeyEnter = leButtonWidget_New();
    TimerInit_ButtonKeyEnter->fn->setPosition(TimerInit_ButtonKeyEnter, 398, 191);
    TimerInit_ButtonKeyEnter->fn->setSize(TimerInit_ButtonKeyEnter, 74, 74);
    TimerInit_ButtonKeyEnter->fn->setScheme(TimerInit_ButtonKeyEnter, &LayerScheme);
    TimerInit_ButtonKeyEnter->fn->setBackgroundType(TimerInit_ButtonKeyEnter, LE_WIDGET_BACKGROUND_NONE);
    TimerInit_ButtonKeyEnter->fn->setBorderType(TimerInit_ButtonKeyEnter, LE_WIDGET_BORDER_NONE);
    TimerInit_ButtonKeyEnter->fn->setPressedImage(TimerInit_ButtonKeyEnter, (leImage*)&ICON_keypad_enter);
    TimerInit_ButtonKeyEnter->fn->setReleasedImage(TimerInit_ButtonKeyEnter, (leImage*)&ICON_keypad_enter);
    TimerInit_ButtonKeyEnter->fn->setImagePosition(TimerInit_ButtonKeyEnter, LE_RELATIVE_POSITION_BEHIND);
    TimerInit_ButtonKeyEnter->fn->setPressedEventCallback(TimerInit_ButtonKeyEnter, event_TimerInit_ButtonKeyEnter_OnPressed);
    TimerInit_ButtonKeyEnter->fn->setReleasedEventCallback(TimerInit_ButtonKeyEnter, event_TimerInit_ButtonKeyEnter_OnReleased);
    root0->fn->addChild(root0, (leWidget*)TimerInit_ButtonKeyEnter);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    TimerInit_OnShow(); // raise event

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_TimerInit(void)
{
}

void screenHide_TimerInit(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    TimerInit_PanelWidget0 = NULL;
    TimerInit_ButtonExit = NULL;
    TimerInit_LabelTimerUserNote = NULL;
    TimerInit_TextFieldTimerMinutes = NULL;
    TimerInit_PanelKeypadBack = NULL;
    TimerInit_ButtonKey0 = NULL;
    TimerInit_ButtonKey1 = NULL;
    TimerInit_ButtonKey2 = NULL;
    TimerInit_ButtonKey3 = NULL;
    TimerInit_ButtonKey4 = NULL;
    TimerInit_ButtonKey5 = NULL;
    TimerInit_ButtonKey6 = NULL;
    TimerInit_ButtonKey7 = NULL;
    TimerInit_ButtonKey8 = NULL;
    TimerInit_ButtonKey9 = NULL;
    TimerInit_ButtonKeyBackSpace = NULL;
    TimerInit_ButtonKeyEnter = NULL;


    showing = LE_FALSE;
}

void screenDestroy_TimerInit(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_TimerInit(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

