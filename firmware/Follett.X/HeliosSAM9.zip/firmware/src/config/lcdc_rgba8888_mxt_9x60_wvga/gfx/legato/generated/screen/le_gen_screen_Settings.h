#ifndef LE_GEN_SCREEN_SETTINGS_H
#define LE_GEN_SCREEN_SETTINGS_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* Settings_Layer0_FillPanel;
extern leButtonWidget* Settings_ButtonBack;
extern leLabelWidget* Settings_LabelSettings;
extern leImageWidget* Settings_SettingsIcon;
extern leLineWidget* Settings_LineDivider;
extern leButtonWidget* Settings_ButtonTemperatureScale;
extern leButtonWidget* Settings_ButtonBrightness;
extern leButtonWidget* Settings_ButtonPerformanceData;
extern leButtonWidget* Settings_ButtonErrorLog;
extern leButtonWidget* Settings_ButtonFirmwareVersions;
extern leButtonWidget* Settings_ButtonServiceSettings;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_Settings_ButtonBack_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonBack_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonTemperatureScale_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonTemperatureScale_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonBrightness_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonBrightness_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonPerformanceData_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonPerformanceData_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonErrorLog_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonErrorLog_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonFirmwareVersions_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonFirmwareVersions_OnReleased(leButtonWidget* btn);
void event_Settings_ButtonServiceSettings_OnPressed(leButtonWidget* btn);
void event_Settings_ButtonServiceSettings_OnReleased(leButtonWidget* btn);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_Settings(void); // called when Legato is initialized
leResult screenShow_Settings(void); // called when screen is shown
void screenHide_Settings(void); // called when screen is hidden
void screenDestroy_Settings(void); // called when Legato is destroyed
void screenUpdate_Settings(void); // called when Legato is updating

leWidget* screenGetRoot_Settings(uint32_t lyrIdx); // gets a root widget for this screen

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_SETTINGS_H
