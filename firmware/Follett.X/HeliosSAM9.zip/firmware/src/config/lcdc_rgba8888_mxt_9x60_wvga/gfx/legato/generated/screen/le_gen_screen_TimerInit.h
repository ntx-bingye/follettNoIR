#ifndef LE_GEN_SCREEN_TIMERINIT_H
#define LE_GEN_SCREEN_TIMERINIT_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* TimerInit_PanelWidget0;
extern leButtonWidget* TimerInit_ButtonExit;
extern leLabelWidget* TimerInit_LabelTimerUserNote;
extern leTextFieldWidget* TimerInit_TextFieldTimerMinutes;
extern leWidget* TimerInit_PanelKeypadBack;
extern leButtonWidget* TimerInit_ButtonKey0;
extern leButtonWidget* TimerInit_ButtonKey1;
extern leButtonWidget* TimerInit_ButtonKey2;
extern leButtonWidget* TimerInit_ButtonKey3;
extern leButtonWidget* TimerInit_ButtonKey4;
extern leButtonWidget* TimerInit_ButtonKey5;
extern leButtonWidget* TimerInit_ButtonKey6;
extern leButtonWidget* TimerInit_ButtonKey7;
extern leButtonWidget* TimerInit_ButtonKey8;
extern leButtonWidget* TimerInit_ButtonKey9;
extern leButtonWidget* TimerInit_ButtonKeyBackSpace;
extern leButtonWidget* TimerInit_ButtonKeyEnter;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_TimerInit_ButtonExit_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonExit_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey0_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey0_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey1_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey1_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey2_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey2_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey3_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey3_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey4_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey4_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey5_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey5_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey6_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey6_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey7_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey7_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey8_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey8_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKey9_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKey9_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKeyBackSpace_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKeyBackSpace_OnReleased(leButtonWidget* btn);
void event_TimerInit_ButtonKeyEnter_OnPressed(leButtonWidget* btn);
void event_TimerInit_ButtonKeyEnter_OnReleased(leButtonWidget* btn);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_TimerInit(void); // called when Legato is initialized
leResult screenShow_TimerInit(void); // called when screen is shown
void screenHide_TimerInit(void); // called when screen is hidden
void screenDestroy_TimerInit(void); // called when Legato is destroyed
void screenUpdate_TimerInit(void); // called when Legato is updating

leWidget* screenGetRoot_TimerInit(uint32_t lyrIdx); // gets a root widget for this screen

// Screen Events:
void TimerInit_OnShow(void); // called when this screen is shown

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_TIMERINIT_H
