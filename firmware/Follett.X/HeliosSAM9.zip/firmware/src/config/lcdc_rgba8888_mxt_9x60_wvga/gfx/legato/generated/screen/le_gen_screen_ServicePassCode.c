#include "gfx/legato/generated/screen/le_gen_screen_ServicePassCode.h"

// screen member widget declarations
leWidget* root0;

leWidget* ServicePassCode_Layer0_FillPanel;
leButtonWidget* ServicePassCode_ButtonReturn;
leLabelWidget* ServicePassCode_LabelEnterPasscode;
leWidget* ServicePassCode_PanelKeyBackground;
leButtonWidget* ServicePassCode_ButtonKey0;
leButtonWidget* ServicePassCode_ButtonKey1;
leButtonWidget* ServicePassCode_ButtonKey2;
leButtonWidget* ServicePassCode_ButtonKey3;
leButtonWidget* ServicePassCode_ButtonKey4;
leButtonWidget* ServicePassCode_ButtonKey5;
leButtonWidget* ServicePassCode_ButtonKey6;
leButtonWidget* ServicePassCode_ButtonKey7;
leButtonWidget* ServicePassCode_ButtonKey8;
leButtonWidget* ServicePassCode_ButtonKey9;
leButtonWidget* ServicePassCode_ButtonKeyBackspace;
leButtonWidget* ServicePassCode_ButtonKeyEnter;
leTextFieldWidget* ServicePassCode_ServiceCodeValue;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_ServicePassCode(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_ServicePassCode(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    ServicePassCode_Layer0_FillPanel = leWidget_New();
    ServicePassCode_Layer0_FillPanel->fn->setPosition(ServicePassCode_Layer0_FillPanel, 0, 0);
    ServicePassCode_Layer0_FillPanel->fn->setSize(ServicePassCode_Layer0_FillPanel, 480, 272);
    ServicePassCode_Layer0_FillPanel->fn->setScheme(ServicePassCode_Layer0_FillPanel, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_Layer0_FillPanel);

    ServicePassCode_ButtonReturn = leButtonWidget_New();
    ServicePassCode_ButtonReturn->fn->setPosition(ServicePassCode_ButtonReturn, 431, 4);
    ServicePassCode_ButtonReturn->fn->setSize(ServicePassCode_ButtonReturn, 45, 45);
    ServicePassCode_ButtonReturn->fn->setScheme(ServicePassCode_ButtonReturn, &BackgroundScheme);
    ServicePassCode_ButtonReturn->fn->setBackgroundType(ServicePassCode_ButtonReturn, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonReturn->fn->setBorderType(ServicePassCode_ButtonReturn, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonReturn->fn->setPressedImage(ServicePassCode_ButtonReturn, (leImage*)&ICON_goBackActive);
    ServicePassCode_ButtonReturn->fn->setReleasedImage(ServicePassCode_ButtonReturn, (leImage*)&ICON_goBackInactive);
    ServicePassCode_ButtonReturn->fn->setPressedEventCallback(ServicePassCode_ButtonReturn, event_ServicePassCode_ButtonReturn_OnPressed);
    ServicePassCode_ButtonReturn->fn->setReleasedEventCallback(ServicePassCode_ButtonReturn, event_ServicePassCode_ButtonReturn_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonReturn);

    ServicePassCode_LabelEnterPasscode = leLabelWidget_New();
    ServicePassCode_LabelEnterPasscode->fn->setPosition(ServicePassCode_LabelEnterPasscode, 50, 36);
    ServicePassCode_LabelEnterPasscode->fn->setSize(ServicePassCode_LabelEnterPasscode, 375, 25);
    ServicePassCode_LabelEnterPasscode->fn->setScheme(ServicePassCode_LabelEnterPasscode, &ForegroundScheme);
    ServicePassCode_LabelEnterPasscode->fn->setBackgroundType(ServicePassCode_LabelEnterPasscode, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_LabelEnterPasscode->fn->setHAlignment(ServicePassCode_LabelEnterPasscode, LE_HALIGN_CENTER);
    ServicePassCode_LabelEnterPasscode->fn->setString(ServicePassCode_LabelEnterPasscode, (leString*)&string_ServiceAgentsEnterPasscode);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_LabelEnterPasscode);

    ServicePassCode_PanelKeyBackground = leWidget_New();
    ServicePassCode_PanelKeyBackground->fn->setPosition(ServicePassCode_PanelKeyBackground, 0, 106);
    ServicePassCode_PanelKeyBackground->fn->setSize(ServicePassCode_PanelKeyBackground, 480, 166);
    ServicePassCode_PanelKeyBackground->fn->setScheme(ServicePassCode_PanelKeyBackground, &KeypadBack);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_PanelKeyBackground);

    ServicePassCode_ButtonKey0 = leButtonWidget_New();
    ServicePassCode_ButtonKey0->fn->setPosition(ServicePassCode_ButtonKey0, 8, 114);
    ServicePassCode_ButtonKey0->fn->setSize(ServicePassCode_ButtonKey0, 74, 74);
    ServicePassCode_ButtonKey0->fn->setScheme(ServicePassCode_ButtonKey0, &LayerScheme);
    ServicePassCode_ButtonKey0->fn->setBackgroundType(ServicePassCode_ButtonKey0, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey0->fn->setBorderType(ServicePassCode_ButtonKey0, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey0->fn->setString(ServicePassCode_ButtonKey0, (leString*)&string_Keypad0);
    ServicePassCode_ButtonKey0->fn->setPressedImage(ServicePassCode_ButtonKey0, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey0->fn->setReleasedImage(ServicePassCode_ButtonKey0, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey0->fn->setImagePosition(ServicePassCode_ButtonKey0, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey0->fn->setReleasedEventCallback(ServicePassCode_ButtonKey0, event_ServicePassCode_ButtonKey0_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey0);

    ServicePassCode_ButtonKey1 = leButtonWidget_New();
    ServicePassCode_ButtonKey1->fn->setPosition(ServicePassCode_ButtonKey1, 86, 114);
    ServicePassCode_ButtonKey1->fn->setSize(ServicePassCode_ButtonKey1, 74, 74);
    ServicePassCode_ButtonKey1->fn->setScheme(ServicePassCode_ButtonKey1, &LayerScheme);
    ServicePassCode_ButtonKey1->fn->setBackgroundType(ServicePassCode_ButtonKey1, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey1->fn->setBorderType(ServicePassCode_ButtonKey1, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey1->fn->setString(ServicePassCode_ButtonKey1, (leString*)&string_Keypad1);
    ServicePassCode_ButtonKey1->fn->setPressedImage(ServicePassCode_ButtonKey1, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey1->fn->setReleasedImage(ServicePassCode_ButtonKey1, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey1->fn->setImagePosition(ServicePassCode_ButtonKey1, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey1->fn->setReleasedEventCallback(ServicePassCode_ButtonKey1, event_ServicePassCode_ButtonKey1_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey1);

    ServicePassCode_ButtonKey2 = leButtonWidget_New();
    ServicePassCode_ButtonKey2->fn->setPosition(ServicePassCode_ButtonKey2, 164, 114);
    ServicePassCode_ButtonKey2->fn->setSize(ServicePassCode_ButtonKey2, 74, 74);
    ServicePassCode_ButtonKey2->fn->setScheme(ServicePassCode_ButtonKey2, &LayerScheme);
    ServicePassCode_ButtonKey2->fn->setBackgroundType(ServicePassCode_ButtonKey2, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey2->fn->setBorderType(ServicePassCode_ButtonKey2, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey2->fn->setString(ServicePassCode_ButtonKey2, (leString*)&string_Keypad2);
    ServicePassCode_ButtonKey2->fn->setPressedImage(ServicePassCode_ButtonKey2, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey2->fn->setReleasedImage(ServicePassCode_ButtonKey2, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey2->fn->setImagePosition(ServicePassCode_ButtonKey2, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey2->fn->setReleasedEventCallback(ServicePassCode_ButtonKey2, event_ServicePassCode_ButtonKey2_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey2);

    ServicePassCode_ButtonKey3 = leButtonWidget_New();
    ServicePassCode_ButtonKey3->fn->setPosition(ServicePassCode_ButtonKey3, 242, 114);
    ServicePassCode_ButtonKey3->fn->setSize(ServicePassCode_ButtonKey3, 74, 74);
    ServicePassCode_ButtonKey3->fn->setScheme(ServicePassCode_ButtonKey3, &LayerScheme);
    ServicePassCode_ButtonKey3->fn->setBackgroundType(ServicePassCode_ButtonKey3, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey3->fn->setBorderType(ServicePassCode_ButtonKey3, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey3->fn->setString(ServicePassCode_ButtonKey3, (leString*)&string_Keypad3);
    ServicePassCode_ButtonKey3->fn->setPressedImage(ServicePassCode_ButtonKey3, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey3->fn->setReleasedImage(ServicePassCode_ButtonKey3, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey3->fn->setImagePosition(ServicePassCode_ButtonKey3, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey3->fn->setReleasedEventCallback(ServicePassCode_ButtonKey3, event_ServicePassCode_ButtonKey3_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey3);

    ServicePassCode_ButtonKey4 = leButtonWidget_New();
    ServicePassCode_ButtonKey4->fn->setPosition(ServicePassCode_ButtonKey4, 320, 114);
    ServicePassCode_ButtonKey4->fn->setSize(ServicePassCode_ButtonKey4, 74, 74);
    ServicePassCode_ButtonKey4->fn->setScheme(ServicePassCode_ButtonKey4, &LayerScheme);
    ServicePassCode_ButtonKey4->fn->setBackgroundType(ServicePassCode_ButtonKey4, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey4->fn->setBorderType(ServicePassCode_ButtonKey4, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey4->fn->setString(ServicePassCode_ButtonKey4, (leString*)&string_Keypad4);
    ServicePassCode_ButtonKey4->fn->setPressedImage(ServicePassCode_ButtonKey4, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey4->fn->setReleasedImage(ServicePassCode_ButtonKey4, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey4->fn->setImagePosition(ServicePassCode_ButtonKey4, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey4->fn->setReleasedEventCallback(ServicePassCode_ButtonKey4, event_ServicePassCode_ButtonKey4_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey4);

    ServicePassCode_ButtonKey5 = leButtonWidget_New();
    ServicePassCode_ButtonKey5->fn->setPosition(ServicePassCode_ButtonKey5, 398, 114);
    ServicePassCode_ButtonKey5->fn->setSize(ServicePassCode_ButtonKey5, 74, 74);
    ServicePassCode_ButtonKey5->fn->setScheme(ServicePassCode_ButtonKey5, &LayerScheme);
    ServicePassCode_ButtonKey5->fn->setBackgroundType(ServicePassCode_ButtonKey5, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey5->fn->setBorderType(ServicePassCode_ButtonKey5, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey5->fn->setString(ServicePassCode_ButtonKey5, (leString*)&string_Keypad5);
    ServicePassCode_ButtonKey5->fn->setPressedImage(ServicePassCode_ButtonKey5, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey5->fn->setReleasedImage(ServicePassCode_ButtonKey5, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey5->fn->setImagePosition(ServicePassCode_ButtonKey5, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey5->fn->setReleasedEventCallback(ServicePassCode_ButtonKey5, event_ServicePassCode_ButtonKey5_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey5);

    ServicePassCode_ButtonKey6 = leButtonWidget_New();
    ServicePassCode_ButtonKey6->fn->setPosition(ServicePassCode_ButtonKey6, 8, 191);
    ServicePassCode_ButtonKey6->fn->setSize(ServicePassCode_ButtonKey6, 74, 74);
    ServicePassCode_ButtonKey6->fn->setScheme(ServicePassCode_ButtonKey6, &LayerScheme);
    ServicePassCode_ButtonKey6->fn->setBackgroundType(ServicePassCode_ButtonKey6, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey6->fn->setBorderType(ServicePassCode_ButtonKey6, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey6->fn->setString(ServicePassCode_ButtonKey6, (leString*)&string_Keypad6);
    ServicePassCode_ButtonKey6->fn->setPressedImage(ServicePassCode_ButtonKey6, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey6->fn->setReleasedImage(ServicePassCode_ButtonKey6, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey6->fn->setImagePosition(ServicePassCode_ButtonKey6, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey6->fn->setReleasedEventCallback(ServicePassCode_ButtonKey6, event_ServicePassCode_ButtonKey6_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey6);

    ServicePassCode_ButtonKey7 = leButtonWidget_New();
    ServicePassCode_ButtonKey7->fn->setPosition(ServicePassCode_ButtonKey7, 86, 191);
    ServicePassCode_ButtonKey7->fn->setSize(ServicePassCode_ButtonKey7, 74, 74);
    ServicePassCode_ButtonKey7->fn->setScheme(ServicePassCode_ButtonKey7, &LayerScheme);
    ServicePassCode_ButtonKey7->fn->setBackgroundType(ServicePassCode_ButtonKey7, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey7->fn->setBorderType(ServicePassCode_ButtonKey7, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey7->fn->setString(ServicePassCode_ButtonKey7, (leString*)&string_Keypad7);
    ServicePassCode_ButtonKey7->fn->setPressedImage(ServicePassCode_ButtonKey7, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey7->fn->setReleasedImage(ServicePassCode_ButtonKey7, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey7->fn->setImagePosition(ServicePassCode_ButtonKey7, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey7->fn->setReleasedEventCallback(ServicePassCode_ButtonKey7, event_ServicePassCode_ButtonKey7_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey7);

    ServicePassCode_ButtonKey8 = leButtonWidget_New();
    ServicePassCode_ButtonKey8->fn->setPosition(ServicePassCode_ButtonKey8, 164, 191);
    ServicePassCode_ButtonKey8->fn->setSize(ServicePassCode_ButtonKey8, 74, 74);
    ServicePassCode_ButtonKey8->fn->setScheme(ServicePassCode_ButtonKey8, &LayerScheme);
    ServicePassCode_ButtonKey8->fn->setBackgroundType(ServicePassCode_ButtonKey8, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey8->fn->setBorderType(ServicePassCode_ButtonKey8, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey8->fn->setString(ServicePassCode_ButtonKey8, (leString*)&string_keypad8);
    ServicePassCode_ButtonKey8->fn->setPressedImage(ServicePassCode_ButtonKey8, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey8->fn->setReleasedImage(ServicePassCode_ButtonKey8, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey8->fn->setImagePosition(ServicePassCode_ButtonKey8, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey8->fn->setReleasedEventCallback(ServicePassCode_ButtonKey8, event_ServicePassCode_ButtonKey8_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey8);

    ServicePassCode_ButtonKey9 = leButtonWidget_New();
    ServicePassCode_ButtonKey9->fn->setPosition(ServicePassCode_ButtonKey9, 242, 191);
    ServicePassCode_ButtonKey9->fn->setSize(ServicePassCode_ButtonKey9, 74, 74);
    ServicePassCode_ButtonKey9->fn->setScheme(ServicePassCode_ButtonKey9, &LayerScheme);
    ServicePassCode_ButtonKey9->fn->setBackgroundType(ServicePassCode_ButtonKey9, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKey9->fn->setBorderType(ServicePassCode_ButtonKey9, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKey9->fn->setString(ServicePassCode_ButtonKey9, (leString*)&string_Keypad9);
    ServicePassCode_ButtonKey9->fn->setPressedImage(ServicePassCode_ButtonKey9, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey9->fn->setReleasedImage(ServicePassCode_ButtonKey9, (leImage*)&ICON_keypad_number2);
    ServicePassCode_ButtonKey9->fn->setImagePosition(ServicePassCode_ButtonKey9, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKey9->fn->setReleasedEventCallback(ServicePassCode_ButtonKey9, event_ServicePassCode_ButtonKey9_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKey9);

    ServicePassCode_ButtonKeyBackspace = leButtonWidget_New();
    ServicePassCode_ButtonKeyBackspace->fn->setPosition(ServicePassCode_ButtonKeyBackspace, 320, 191);
    ServicePassCode_ButtonKeyBackspace->fn->setSize(ServicePassCode_ButtonKeyBackspace, 74, 74);
    ServicePassCode_ButtonKeyBackspace->fn->setScheme(ServicePassCode_ButtonKeyBackspace, &LayerScheme);
    ServicePassCode_ButtonKeyBackspace->fn->setBackgroundType(ServicePassCode_ButtonKeyBackspace, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKeyBackspace->fn->setBorderType(ServicePassCode_ButtonKeyBackspace, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKeyBackspace->fn->setPressedImage(ServicePassCode_ButtonKeyBackspace, (leImage*)&ICON_keypad_del);
    ServicePassCode_ButtonKeyBackspace->fn->setReleasedImage(ServicePassCode_ButtonKeyBackspace, (leImage*)&ICON_keypad_del);
    ServicePassCode_ButtonKeyBackspace->fn->setImagePosition(ServicePassCode_ButtonKeyBackspace, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKeyBackspace->fn->setReleasedEventCallback(ServicePassCode_ButtonKeyBackspace, event_ServicePassCode_ButtonKeyBackspace_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKeyBackspace);

    ServicePassCode_ButtonKeyEnter = leButtonWidget_New();
    ServicePassCode_ButtonKeyEnter->fn->setPosition(ServicePassCode_ButtonKeyEnter, 398, 191);
    ServicePassCode_ButtonKeyEnter->fn->setSize(ServicePassCode_ButtonKeyEnter, 74, 74);
    ServicePassCode_ButtonKeyEnter->fn->setScheme(ServicePassCode_ButtonKeyEnter, &LayerScheme);
    ServicePassCode_ButtonKeyEnter->fn->setBackgroundType(ServicePassCode_ButtonKeyEnter, LE_WIDGET_BACKGROUND_NONE);
    ServicePassCode_ButtonKeyEnter->fn->setBorderType(ServicePassCode_ButtonKeyEnter, LE_WIDGET_BORDER_NONE);
    ServicePassCode_ButtonKeyEnter->fn->setPressedImage(ServicePassCode_ButtonKeyEnter, (leImage*)&ICON_keypad_enter);
    ServicePassCode_ButtonKeyEnter->fn->setReleasedImage(ServicePassCode_ButtonKeyEnter, (leImage*)&ICON_keypad_enter);
    ServicePassCode_ButtonKeyEnter->fn->setImagePosition(ServicePassCode_ButtonKeyEnter, LE_RELATIVE_POSITION_BEHIND);
    ServicePassCode_ButtonKeyEnter->fn->setReleasedEventCallback(ServicePassCode_ButtonKeyEnter, event_ServicePassCode_ButtonKeyEnter_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ButtonKeyEnter);

    ServicePassCode_ServiceCodeValue = leTextFieldWidget_New();
    ServicePassCode_ServiceCodeValue->fn->setPosition(ServicePassCode_ServiceCodeValue, 189, 64);
    ServicePassCode_ServiceCodeValue->fn->setScheme(ServicePassCode_ServiceCodeValue, &defaultScheme);
    ServicePassCode_ServiceCodeValue->fn->setHAlignment(ServicePassCode_ServiceCodeValue, LE_HALIGN_LEFT);
    root0->fn->addChild(root0, (leWidget*)ServicePassCode_ServiceCodeValue);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_ServicePassCode(void)
{
}

void screenHide_ServicePassCode(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    ServicePassCode_Layer0_FillPanel = NULL;
    ServicePassCode_ButtonReturn = NULL;
    ServicePassCode_LabelEnterPasscode = NULL;
    ServicePassCode_PanelKeyBackground = NULL;
    ServicePassCode_ButtonKey0 = NULL;
    ServicePassCode_ButtonKey1 = NULL;
    ServicePassCode_ButtonKey2 = NULL;
    ServicePassCode_ButtonKey3 = NULL;
    ServicePassCode_ButtonKey4 = NULL;
    ServicePassCode_ButtonKey5 = NULL;
    ServicePassCode_ButtonKey6 = NULL;
    ServicePassCode_ButtonKey7 = NULL;
    ServicePassCode_ButtonKey8 = NULL;
    ServicePassCode_ButtonKey9 = NULL;
    ServicePassCode_ButtonKeyBackspace = NULL;
    ServicePassCode_ButtonKeyEnter = NULL;
    ServicePassCode_ServiceCodeValue = NULL;


    showing = LE_FALSE;
}

void screenDestroy_ServicePassCode(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_ServicePassCode(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

