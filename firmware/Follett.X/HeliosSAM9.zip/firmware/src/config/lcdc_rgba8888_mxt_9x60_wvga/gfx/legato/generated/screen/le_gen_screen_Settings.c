#include "gfx/legato/generated/screen/le_gen_screen_Settings.h"

// screen member widget declarations
leWidget* root0;

leWidget* Settings_Layer0_FillPanel;
leButtonWidget* Settings_ButtonBack;
leLabelWidget* Settings_LabelSettings;
leImageWidget* Settings_SettingsIcon;
leLineWidget* Settings_LineDivider;
leButtonWidget* Settings_ButtonTemperatureScale;
leButtonWidget* Settings_ButtonBrightness;
leButtonWidget* Settings_ButtonPerformanceData;
leButtonWidget* Settings_ButtonErrorLog;
leButtonWidget* Settings_ButtonFirmwareVersions;
leButtonWidget* Settings_ButtonServiceSettings;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_Settings(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_Settings(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    Settings_Layer0_FillPanel = leWidget_New();
    Settings_Layer0_FillPanel->fn->setPosition(Settings_Layer0_FillPanel, 0, 0);
    Settings_Layer0_FillPanel->fn->setSize(Settings_Layer0_FillPanel, 480, 272);
    Settings_Layer0_FillPanel->fn->setScheme(Settings_Layer0_FillPanel, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)Settings_Layer0_FillPanel);

    Settings_ButtonBack = leButtonWidget_New();
    Settings_ButtonBack->fn->setPosition(Settings_ButtonBack, 431, 4);
    Settings_ButtonBack->fn->setSize(Settings_ButtonBack, 45, 45);
    Settings_ButtonBack->fn->setScheme(Settings_ButtonBack, &BackgroundScheme);
    Settings_ButtonBack->fn->setBackgroundType(Settings_ButtonBack, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonBack->fn->setBorderType(Settings_ButtonBack, LE_WIDGET_BORDER_NONE);
    Settings_ButtonBack->fn->setPressedImage(Settings_ButtonBack, (leImage*)&ICON_goBackActive);
    Settings_ButtonBack->fn->setReleasedImage(Settings_ButtonBack, (leImage*)&ICON_goBackInactive);
    Settings_ButtonBack->fn->setPressedEventCallback(Settings_ButtonBack, event_Settings_ButtonBack_OnPressed);
    Settings_ButtonBack->fn->setReleasedEventCallback(Settings_ButtonBack, event_Settings_ButtonBack_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonBack);

    Settings_LabelSettings = leLabelWidget_New();
    Settings_LabelSettings->fn->setPosition(Settings_LabelSettings, 45, 15);
    Settings_LabelSettings->fn->setSize(Settings_LabelSettings, 150, 25);
    Settings_LabelSettings->fn->setScheme(Settings_LabelSettings, &BackgroundScheme);
    Settings_LabelSettings->fn->setBackgroundType(Settings_LabelSettings, LE_WIDGET_BACKGROUND_NONE);
    Settings_LabelSettings->fn->setString(Settings_LabelSettings, (leString*)&string_SettingsMenu);
    root0->fn->addChild(root0, (leWidget*)Settings_LabelSettings);

    Settings_SettingsIcon = leImageWidget_New();
    Settings_SettingsIcon->fn->setPosition(Settings_SettingsIcon, 5, 5);
    Settings_SettingsIcon->fn->setSize(Settings_SettingsIcon, 40, 40);
    Settings_SettingsIcon->fn->setScheme(Settings_SettingsIcon, &BackgroundScheme);
    Settings_SettingsIcon->fn->setBorderType(Settings_SettingsIcon, LE_WIDGET_BORDER_NONE);
    Settings_SettingsIcon->fn->setImage(Settings_SettingsIcon, (leImage*)&gear);
    root0->fn->addChild(root0, (leWidget*)Settings_SettingsIcon);

    Settings_LineDivider = leLineWidget_New();
    Settings_LineDivider->fn->setPosition(Settings_LineDivider, 0, 46);
    Settings_LineDivider->fn->setSize(Settings_LineDivider, 480, 4);
    Settings_LineDivider->fn->setScheme(Settings_LineDivider, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)Settings_LineDivider);

    Settings_ButtonTemperatureScale = leButtonWidget_New();
    Settings_ButtonTemperatureScale->fn->setPosition(Settings_ButtonTemperatureScale, 40, 70);
    Settings_ButtonTemperatureScale->fn->setSize(Settings_ButtonTemperatureScale, 175, 40);
    Settings_ButtonTemperatureScale->fn->setScheme(Settings_ButtonTemperatureScale, &BackgroundScheme);
    Settings_ButtonTemperatureScale->fn->setBackgroundType(Settings_ButtonTemperatureScale, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonTemperatureScale->fn->setBorderType(Settings_ButtonTemperatureScale, LE_WIDGET_BORDER_LINE);
    Settings_ButtonTemperatureScale->fn->setString(Settings_ButtonTemperatureScale, (leString*)&string_TemperatureScale);
    Settings_ButtonTemperatureScale->fn->setPressedEventCallback(Settings_ButtonTemperatureScale, event_Settings_ButtonTemperatureScale_OnPressed);
    Settings_ButtonTemperatureScale->fn->setReleasedEventCallback(Settings_ButtonTemperatureScale, event_Settings_ButtonTemperatureScale_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonTemperatureScale);

    Settings_ButtonBrightness = leButtonWidget_New();
    Settings_ButtonBrightness->fn->setPosition(Settings_ButtonBrightness, 40, 130);
    Settings_ButtonBrightness->fn->setSize(Settings_ButtonBrightness, 175, 40);
    Settings_ButtonBrightness->fn->setScheme(Settings_ButtonBrightness, &BackgroundScheme);
    Settings_ButtonBrightness->fn->setBackgroundType(Settings_ButtonBrightness, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonBrightness->fn->setBorderType(Settings_ButtonBrightness, LE_WIDGET_BORDER_LINE);
    Settings_ButtonBrightness->fn->setString(Settings_ButtonBrightness, (leString*)&string_ScreenBrightness);
    Settings_ButtonBrightness->fn->setPressedEventCallback(Settings_ButtonBrightness, event_Settings_ButtonBrightness_OnPressed);
    Settings_ButtonBrightness->fn->setReleasedEventCallback(Settings_ButtonBrightness, event_Settings_ButtonBrightness_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonBrightness);

    Settings_ButtonPerformanceData = leButtonWidget_New();
    Settings_ButtonPerformanceData->fn->setPosition(Settings_ButtonPerformanceData, 40, 190);
    Settings_ButtonPerformanceData->fn->setSize(Settings_ButtonPerformanceData, 175, 40);
    Settings_ButtonPerformanceData->fn->setScheme(Settings_ButtonPerformanceData, &BackgroundScheme);
    Settings_ButtonPerformanceData->fn->setBackgroundType(Settings_ButtonPerformanceData, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonPerformanceData->fn->setBorderType(Settings_ButtonPerformanceData, LE_WIDGET_BORDER_LINE);
    Settings_ButtonPerformanceData->fn->setString(Settings_ButtonPerformanceData, (leString*)&string_PerformanceDataView);
    Settings_ButtonPerformanceData->fn->setPressedEventCallback(Settings_ButtonPerformanceData, event_Settings_ButtonPerformanceData_OnPressed);
    Settings_ButtonPerformanceData->fn->setReleasedEventCallback(Settings_ButtonPerformanceData, event_Settings_ButtonPerformanceData_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonPerformanceData);

    Settings_ButtonErrorLog = leButtonWidget_New();
    Settings_ButtonErrorLog->fn->setPosition(Settings_ButtonErrorLog, 270, 70);
    Settings_ButtonErrorLog->fn->setSize(Settings_ButtonErrorLog, 175, 40);
    Settings_ButtonErrorLog->fn->setScheme(Settings_ButtonErrorLog, &BackgroundScheme);
    Settings_ButtonErrorLog->fn->setBackgroundType(Settings_ButtonErrorLog, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonErrorLog->fn->setBorderType(Settings_ButtonErrorLog, LE_WIDGET_BORDER_LINE);
    Settings_ButtonErrorLog->fn->setString(Settings_ButtonErrorLog, (leString*)&string_ErrorLogView);
    Settings_ButtonErrorLog->fn->setPressedEventCallback(Settings_ButtonErrorLog, event_Settings_ButtonErrorLog_OnPressed);
    Settings_ButtonErrorLog->fn->setReleasedEventCallback(Settings_ButtonErrorLog, event_Settings_ButtonErrorLog_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonErrorLog);

    Settings_ButtonFirmwareVersions = leButtonWidget_New();
    Settings_ButtonFirmwareVersions->fn->setPosition(Settings_ButtonFirmwareVersions, 270, 130);
    Settings_ButtonFirmwareVersions->fn->setSize(Settings_ButtonFirmwareVersions, 175, 40);
    Settings_ButtonFirmwareVersions->fn->setScheme(Settings_ButtonFirmwareVersions, &BackgroundScheme);
    Settings_ButtonFirmwareVersions->fn->setBackgroundType(Settings_ButtonFirmwareVersions, LE_WIDGET_BACKGROUND_NONE);
    Settings_ButtonFirmwareVersions->fn->setBorderType(Settings_ButtonFirmwareVersions, LE_WIDGET_BORDER_LINE);
    Settings_ButtonFirmwareVersions->fn->setString(Settings_ButtonFirmwareVersions, (leString*)&string_FirmwareVersionsView);
    Settings_ButtonFirmwareVersions->fn->setPressedEventCallback(Settings_ButtonFirmwareVersions, event_Settings_ButtonFirmwareVersions_OnPressed);
    Settings_ButtonFirmwareVersions->fn->setReleasedEventCallback(Settings_ButtonFirmwareVersions, event_Settings_ButtonFirmwareVersions_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonFirmwareVersions);

    Settings_ButtonServiceSettings = leButtonWidget_New();
    Settings_ButtonServiceSettings->fn->setPosition(Settings_ButtonServiceSettings, 270, 190);
    Settings_ButtonServiceSettings->fn->setSize(Settings_ButtonServiceSettings, 175, 40);
    Settings_ButtonServiceSettings->fn->setScheme(Settings_ButtonServiceSettings, &BackgroundScheme);
    Settings_ButtonServiceSettings->fn->setBorderType(Settings_ButtonServiceSettings, LE_WIDGET_BORDER_LINE);
    Settings_ButtonServiceSettings->fn->setString(Settings_ButtonServiceSettings, (leString*)&string_ServiceTechnicianSettings);
    Settings_ButtonServiceSettings->fn->setPressedEventCallback(Settings_ButtonServiceSettings, event_Settings_ButtonServiceSettings_OnPressed);
    Settings_ButtonServiceSettings->fn->setReleasedEventCallback(Settings_ButtonServiceSettings, event_Settings_ButtonServiceSettings_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Settings_ButtonServiceSettings);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_Settings(void)
{
}

void screenHide_Settings(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    Settings_Layer0_FillPanel = NULL;
    Settings_ButtonBack = NULL;
    Settings_LabelSettings = NULL;
    Settings_SettingsIcon = NULL;
    Settings_LineDivider = NULL;
    Settings_ButtonTemperatureScale = NULL;
    Settings_ButtonBrightness = NULL;
    Settings_ButtonPerformanceData = NULL;
    Settings_ButtonErrorLog = NULL;
    Settings_ButtonFirmwareVersions = NULL;
    Settings_ButtonServiceSettings = NULL;


    showing = LE_FALSE;
}

void screenDestroy_Settings(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_Settings(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

