#include "gfx/legato/generated/le_gen_init.h"

static int32_t currentScreen;
static int32_t changingToScreen;

void legato_initializeScreenState(void)
{
    leSetStringTable(&stringTable);

    initializeStrings();

    screenInit_Home();
    screenInit_SelectCookMode();
    screenInit_PowerModeSingle();
    screenInit_TemperatureModeSingle();
    screenInit_TimerInit();
    screenInit_Settings();
    screenInit_Error();
    screenInit_PerformanceData();
    screenInit_ErrorLog();
    screenInit_FirmwareVersions();
    screenInit_ServicePassCode();
    screenInit_ServiceAgentSettingsMaximumWattage();
    screenInit_ServiceAgentSettingsVoltageCalibration();
    screenInit_ServiceAgentSettingsLimitMaximumCurrent();
    screenInit_TemperatureScale();
    screenInit_ScreenBrightness1();
    screenInit_ServiceMenu();

    currentScreen = -1;
    changingToScreen = -1;

    legato_showScreen(screenID_Home);
}

uint32_t legato_getCurrentScreen(void)
{
    return currentScreen;
}

static void legato_hideCurrentScreen(void)
{
    switch(currentScreen)
    {
        case screenID_Home:
        {
            screenHide_Home();
            currentScreen = 0;
            break;
        }
        case screenID_SelectCookMode:
        {
            screenHide_SelectCookMode();
            currentScreen = 0;
            break;
        }
        case screenID_PowerModeSingle:
        {
            screenHide_PowerModeSingle();
            currentScreen = 0;
            break;
        }
        case screenID_TemperatureModeSingle:
        {
            screenHide_TemperatureModeSingle();
            currentScreen = 0;
            break;
        }
        case screenID_TimerInit:
        {
            screenHide_TimerInit();
            currentScreen = 0;
            break;
        }
        case screenID_Settings:
        {
            screenHide_Settings();
            currentScreen = 0;
            break;
        }
        case screenID_Error:
        {
            screenHide_Error();
            currentScreen = 0;
            break;
        }
        case screenID_PerformanceData:
        {
            screenHide_PerformanceData();
            currentScreen = 0;
            break;
        }
        case screenID_ErrorLog:
        {
            screenHide_ErrorLog();
            currentScreen = 0;
            break;
        }
        case screenID_FirmwareVersions:
        {
            screenHide_FirmwareVersions();
            currentScreen = 0;
            break;
        }
        case screenID_ServicePassCode:
        {
            screenHide_ServicePassCode();
            currentScreen = 0;
            break;
        }
        case screenID_ServiceAgentSettingsMaximumWattage:
        {
            screenHide_ServiceAgentSettingsMaximumWattage();
            currentScreen = 0;
            break;
        }
        case screenID_ServiceAgentSettingsVoltageCalibration:
        {
            screenHide_ServiceAgentSettingsVoltageCalibration();
            currentScreen = 0;
            break;
        }
        case screenID_ServiceAgentSettingsLimitMaximumCurrent:
        {
            screenHide_ServiceAgentSettingsLimitMaximumCurrent();
            currentScreen = 0;
            break;
        }
        case screenID_TemperatureScale:
        {
            screenHide_TemperatureScale();
            currentScreen = 0;
            break;
        }
        case screenID_ScreenBrightness1:
        {
            screenHide_ScreenBrightness1();
            currentScreen = 0;
            break;
        }
        case screenID_ServiceMenu:
        {
            screenHide_ServiceMenu();
            currentScreen = 0;
            break;
        }
    }
}

void legato_showScreen(uint32_t id)
{
    if(changingToScreen >= 0)
        return;

    changingToScreen = id;
}

void legato_updateScreenState(void)
{
    if(changingToScreen >= 0)
    {
        legato_hideCurrentScreen();

        switch(changingToScreen)
        {
            case screenID_Home:
            {
                screenShow_Home();
                break;
            }
            case screenID_SelectCookMode:
            {
                screenShow_SelectCookMode();
                break;
            }
            case screenID_PowerModeSingle:
            {
                screenShow_PowerModeSingle();
                break;
            }
            case screenID_TemperatureModeSingle:
            {
                screenShow_TemperatureModeSingle();
                break;
            }
            case screenID_TimerInit:
            {
                screenShow_TimerInit();
                break;
            }
            case screenID_Settings:
            {
                screenShow_Settings();
                break;
            }
            case screenID_Error:
            {
                screenShow_Error();
                break;
            }
            case screenID_PerformanceData:
            {
                screenShow_PerformanceData();
                break;
            }
            case screenID_ErrorLog:
            {
                screenShow_ErrorLog();
                break;
            }
            case screenID_FirmwareVersions:
            {
                screenShow_FirmwareVersions();
                break;
            }
            case screenID_ServicePassCode:
            {
                screenShow_ServicePassCode();
                break;
            }
            case screenID_ServiceAgentSettingsMaximumWattage:
            {
                screenShow_ServiceAgentSettingsMaximumWattage();
                break;
            }
            case screenID_ServiceAgentSettingsVoltageCalibration:
            {
                screenShow_ServiceAgentSettingsVoltageCalibration();
                break;
            }
            case screenID_ServiceAgentSettingsLimitMaximumCurrent:
            {
                screenShow_ServiceAgentSettingsLimitMaximumCurrent();
                break;
            }
            case screenID_TemperatureScale:
            {
                screenShow_TemperatureScale();
                break;
            }
            case screenID_ScreenBrightness1:
            {
                screenShow_ScreenBrightness1();
                break;
            }
            case screenID_ServiceMenu:
            {
                screenShow_ServiceMenu();
                break;
            }
        }

        currentScreen = changingToScreen;
        changingToScreen = -1;
    }

    switch(currentScreen)
    {
        case screenID_Home:
        {
            screenUpdate_Home();
            break;
        }
        case screenID_SelectCookMode:
        {
            screenUpdate_SelectCookMode();
            break;
        }
        case screenID_PowerModeSingle:
        {
            screenUpdate_PowerModeSingle();
            break;
        }
        case screenID_TemperatureModeSingle:
        {
            screenUpdate_TemperatureModeSingle();
            break;
        }
        case screenID_TimerInit:
        {
            screenUpdate_TimerInit();
            break;
        }
        case screenID_Settings:
        {
            screenUpdate_Settings();
            break;
        }
        case screenID_Error:
        {
            screenUpdate_Error();
            break;
        }
        case screenID_PerformanceData:
        {
            screenUpdate_PerformanceData();
            break;
        }
        case screenID_ErrorLog:
        {
            screenUpdate_ErrorLog();
            break;
        }
        case screenID_FirmwareVersions:
        {
            screenUpdate_FirmwareVersions();
            break;
        }
        case screenID_ServicePassCode:
        {
            screenUpdate_ServicePassCode();
            break;
        }
        case screenID_ServiceAgentSettingsMaximumWattage:
        {
            screenUpdate_ServiceAgentSettingsMaximumWattage();
            break;
        }
        case screenID_ServiceAgentSettingsVoltageCalibration:
        {
            screenUpdate_ServiceAgentSettingsVoltageCalibration();
            break;
        }
        case screenID_ServiceAgentSettingsLimitMaximumCurrent:
        {
            screenUpdate_ServiceAgentSettingsLimitMaximumCurrent();
            break;
        }
        case screenID_TemperatureScale:
        {
            screenUpdate_TemperatureScale();
            break;
        }
        case screenID_ScreenBrightness1:
        {
            screenUpdate_ScreenBrightness1();
            break;
        }
        case screenID_ServiceMenu:
        {
            screenUpdate_ServiceMenu();
            break;
        }
    }
}

leBool legato_isChangingScreens(void)
{
    return changingToScreen != -1;
}

