#include "gfx/legato/generated/screen/le_gen_screen_ServiceAgentSettingsMaximumWattage.h"

// screen member widget declarations
leWidget* root0;

leWidget* ServiceAgentSettingsMaximumWattage_Layer0_FillPanel;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonGearICON;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonExit;
leLabelWidget* ServiceAgentSettingsMaximumWattage_LabelMaximumWattage;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonWattage1;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonWattage2;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonWattage3;
leButtonWidget* ServiceAgentSettingsMaximumWattage_ButtonWattage4;
leLabelWidget* ServiceAgentSettingsMaximumWattage_ServiceAgentSettings;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_ServiceAgentSettingsMaximumWattage(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_ServiceAgentSettingsMaximumWattage(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    ServiceAgentSettingsMaximumWattage_Layer0_FillPanel = leWidget_New();
    ServiceAgentSettingsMaximumWattage_Layer0_FillPanel->fn->setPosition(ServiceAgentSettingsMaximumWattage_Layer0_FillPanel, 1, -1);
    ServiceAgentSettingsMaximumWattage_Layer0_FillPanel->fn->setSize(ServiceAgentSettingsMaximumWattage_Layer0_FillPanel, 480, 272);
    ServiceAgentSettingsMaximumWattage_Layer0_FillPanel->fn->setScheme(ServiceAgentSettingsMaximumWattage_Layer0_FillPanel, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_Layer0_FillPanel);

    ServiceAgentSettingsMaximumWattage_ButtonGearICON = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonGearICON, 5, 5);
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonGearICON, 45, 45);
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonGearICON, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setBackgroundType(ServiceAgentSettingsMaximumWattage_ButtonGearICON, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonGearICON, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsMaximumWattage_ButtonGearICON->fn->setReleasedImage(ServiceAgentSettingsMaximumWattage_ButtonGearICON, (leImage*)&gear);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonGearICON);

    ServiceAgentSettingsMaximumWattage_ButtonExit = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonExit, 431, 4);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonExit, 45, 45);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonExit, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setBackgroundType(ServiceAgentSettingsMaximumWattage_ButtonExit, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonExit, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setPressedImage(ServiceAgentSettingsMaximumWattage_ButtonExit, (leImage*)&ICON_goBackActive);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setReleasedImage(ServiceAgentSettingsMaximumWattage_ButtonExit, (leImage*)&ICON_goBackInactive);
    ServiceAgentSettingsMaximumWattage_ButtonExit->fn->setReleasedEventCallback(ServiceAgentSettingsMaximumWattage_ButtonExit, event_ServiceAgentSettingsMaximumWattage_ButtonExit_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonExit);

    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage = leLabelWidget_New();
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage->fn->setPosition(ServiceAgentSettingsMaximumWattage_LabelMaximumWattage, 30, 65);
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage->fn->setSize(ServiceAgentSettingsMaximumWattage_LabelMaximumWattage, 190, 25);
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage->fn->setScheme(ServiceAgentSettingsMaximumWattage_LabelMaximumWattage, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage->fn->setBackgroundType(ServiceAgentSettingsMaximumWattage_LabelMaximumWattage, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage->fn->setString(ServiceAgentSettingsMaximumWattage_LabelMaximumWattage, (leString*)&string_MaximumWattage);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_LabelMaximumWattage);

    ServiceAgentSettingsMaximumWattage_ButtonWattage1 = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonWattage1->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonWattage1, 220, 67);
    ServiceAgentSettingsMaximumWattage_ButtonWattage1->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonWattage1, 220, 25);
    ServiceAgentSettingsMaximumWattage_ButtonWattage1->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonWattage1, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonWattage1->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonWattage1, LE_WIDGET_BORDER_LINE);
    ServiceAgentSettingsMaximumWattage_ButtonWattage1->fn->setString(ServiceAgentSettingsMaximumWattage_ButtonWattage1, (leString*)&string_MC2000);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonWattage1);

    ServiceAgentSettingsMaximumWattage_ButtonWattage2 = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonWattage2->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonWattage2, 220, 91);
    ServiceAgentSettingsMaximumWattage_ButtonWattage2->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonWattage2, 220, 25);
    ServiceAgentSettingsMaximumWattage_ButtonWattage2->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonWattage2, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonWattage2->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonWattage2, LE_WIDGET_BORDER_LINE);
    ServiceAgentSettingsMaximumWattage_ButtonWattage2->fn->setString(ServiceAgentSettingsMaximumWattage_ButtonWattage2, (leString*)&string_MC2500);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonWattage2);

    ServiceAgentSettingsMaximumWattage_ButtonWattage3 = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonWattage3->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonWattage3, 220, 115);
    ServiceAgentSettingsMaximumWattage_ButtonWattage3->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonWattage3, 220, 25);
    ServiceAgentSettingsMaximumWattage_ButtonWattage3->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonWattage3, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonWattage3->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonWattage3, LE_WIDGET_BORDER_LINE);
    ServiceAgentSettingsMaximumWattage_ButtonWattage3->fn->setString(ServiceAgentSettingsMaximumWattage_ButtonWattage3, (leString*)&string_MC3000);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonWattage3);

    ServiceAgentSettingsMaximumWattage_ButtonWattage4 = leButtonWidget_New();
    ServiceAgentSettingsMaximumWattage_ButtonWattage4->fn->setPosition(ServiceAgentSettingsMaximumWattage_ButtonWattage4, 220, 139);
    ServiceAgentSettingsMaximumWattage_ButtonWattage4->fn->setSize(ServiceAgentSettingsMaximumWattage_ButtonWattage4, 220, 25);
    ServiceAgentSettingsMaximumWattage_ButtonWattage4->fn->setScheme(ServiceAgentSettingsMaximumWattage_ButtonWattage4, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ButtonWattage4->fn->setBorderType(ServiceAgentSettingsMaximumWattage_ButtonWattage4, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsMaximumWattage_ButtonWattage4->fn->setString(ServiceAgentSettingsMaximumWattage_ButtonWattage4, (leString*)&string_MC3500);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ButtonWattage4);

    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings = leLabelWidget_New();
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings->fn->setPosition(ServiceAgentSettingsMaximumWattage_ServiceAgentSettings, 45, 15);
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings->fn->setSize(ServiceAgentSettingsMaximumWattage_ServiceAgentSettings, 200, 25);
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings->fn->setScheme(ServiceAgentSettingsMaximumWattage_ServiceAgentSettings, &ForegroundScheme);
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings->fn->setBackgroundType(ServiceAgentSettingsMaximumWattage_ServiceAgentSettings, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings->fn->setString(ServiceAgentSettingsMaximumWattage_ServiceAgentSettings, (leString*)&string_WattageSelection);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsMaximumWattage_ServiceAgentSettings);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_ServiceAgentSettingsMaximumWattage(void)
{
}

void screenHide_ServiceAgentSettingsMaximumWattage(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    ServiceAgentSettingsMaximumWattage_Layer0_FillPanel = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonGearICON = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonExit = NULL;
    ServiceAgentSettingsMaximumWattage_LabelMaximumWattage = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonWattage1 = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonWattage2 = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonWattage3 = NULL;
    ServiceAgentSettingsMaximumWattage_ButtonWattage4 = NULL;
    ServiceAgentSettingsMaximumWattage_ServiceAgentSettings = NULL;


    showing = LE_FALSE;
}

void screenDestroy_ServiceAgentSettingsMaximumWattage(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_ServiceAgentSettingsMaximumWattage(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

