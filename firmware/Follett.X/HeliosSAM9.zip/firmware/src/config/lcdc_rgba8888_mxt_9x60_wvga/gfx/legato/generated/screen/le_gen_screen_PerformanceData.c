#include "gfx/legato/generated/screen/le_gen_screen_PerformanceData.h"

// screen member widget declarations
leWidget* root0;

leWidget* PerformanceData_Layer0_FillPanel;
leImageWidget* PerformanceData_PerformaceDataIcon;
leLabelWidget* PerformanceData_LabelOperationalData;
leLabelWidget* PerformanceData_LabelVoltageMeasured;
leLabelWidget* PerformanceData_LabelFrequencyZeroCross;
leLabelWidget* PerformanceData_LabelTopGlassTemperatureMeasured;
leLabelWidget* PerformanceData_LabelWattageCalculated;
leButtonWidget* PerformanceData_ButtonBack;
leLabelWidget* PerformanceData_LabelVoltageValue;
leLabelWidget* PerformanceData_LabelLineFrequencyValue;
leLabelWidget* PerformanceData_LabelGlassTempValue;
leLabelWidget* PerformanceData_LabelWattageValue;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_PerformanceData(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_PerformanceData(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    PerformanceData_Layer0_FillPanel = leWidget_New();
    PerformanceData_Layer0_FillPanel->fn->setPosition(PerformanceData_Layer0_FillPanel, 0, 0);
    PerformanceData_Layer0_FillPanel->fn->setSize(PerformanceData_Layer0_FillPanel, 480, 272);
    PerformanceData_Layer0_FillPanel->fn->setScheme(PerformanceData_Layer0_FillPanel, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_Layer0_FillPanel);

    PerformanceData_PerformaceDataIcon = leImageWidget_New();
    PerformanceData_PerformaceDataIcon->fn->setPosition(PerformanceData_PerformaceDataIcon, 5, 5);
    PerformanceData_PerformaceDataIcon->fn->setSize(PerformanceData_PerformaceDataIcon, 40, 40);
    PerformanceData_PerformaceDataIcon->fn->setScheme(PerformanceData_PerformaceDataIcon, &BackgroundScheme);
    PerformanceData_PerformaceDataIcon->fn->setBackgroundType(PerformanceData_PerformaceDataIcon, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_PerformaceDataIcon->fn->setBorderType(PerformanceData_PerformaceDataIcon, LE_WIDGET_BORDER_NONE);
    PerformanceData_PerformaceDataIcon->fn->setImage(PerformanceData_PerformaceDataIcon, (leImage*)&gear);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_PerformaceDataIcon);

    PerformanceData_LabelOperationalData = leLabelWidget_New();
    PerformanceData_LabelOperationalData->fn->setPosition(PerformanceData_LabelOperationalData, 50, 15);
    PerformanceData_LabelOperationalData->fn->setSize(PerformanceData_LabelOperationalData, 225, 25);
    PerformanceData_LabelOperationalData->fn->setScheme(PerformanceData_LabelOperationalData, &BackgroundScheme);
    PerformanceData_LabelOperationalData->fn->setBackgroundType(PerformanceData_LabelOperationalData, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelOperationalData->fn->setString(PerformanceData_LabelOperationalData, (leString*)&string_PerformanceDataView);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelOperationalData);

    PerformanceData_LabelVoltageMeasured = leLabelWidget_New();
    PerformanceData_LabelVoltageMeasured->fn->setPosition(PerformanceData_LabelVoltageMeasured, 40, 60);
    PerformanceData_LabelVoltageMeasured->fn->setSize(PerformanceData_LabelVoltageMeasured, 180, 30);
    PerformanceData_LabelVoltageMeasured->fn->setScheme(PerformanceData_LabelVoltageMeasured, &BackgroundScheme);
    PerformanceData_LabelVoltageMeasured->fn->setBackgroundType(PerformanceData_LabelVoltageMeasured, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelVoltageMeasured->fn->setString(PerformanceData_LabelVoltageMeasured, (leString*)&string_LineVoltage);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelVoltageMeasured);

    PerformanceData_LabelFrequencyZeroCross = leLabelWidget_New();
    PerformanceData_LabelFrequencyZeroCross->fn->setPosition(PerformanceData_LabelFrequencyZeroCross, 40, 105);
    PerformanceData_LabelFrequencyZeroCross->fn->setSize(PerformanceData_LabelFrequencyZeroCross, 180, 25);
    PerformanceData_LabelFrequencyZeroCross->fn->setScheme(PerformanceData_LabelFrequencyZeroCross, &BackgroundScheme);
    PerformanceData_LabelFrequencyZeroCross->fn->setBackgroundType(PerformanceData_LabelFrequencyZeroCross, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelFrequencyZeroCross->fn->setString(PerformanceData_LabelFrequencyZeroCross, (leString*)&string_LineFrequency);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelFrequencyZeroCross);

    PerformanceData_LabelTopGlassTemperatureMeasured = leLabelWidget_New();
    PerformanceData_LabelTopGlassTemperatureMeasured->fn->setPosition(PerformanceData_LabelTopGlassTemperatureMeasured, 40, 150);
    PerformanceData_LabelTopGlassTemperatureMeasured->fn->setSize(PerformanceData_LabelTopGlassTemperatureMeasured, 180, 25);
    PerformanceData_LabelTopGlassTemperatureMeasured->fn->setScheme(PerformanceData_LabelTopGlassTemperatureMeasured, &BackgroundScheme);
    PerformanceData_LabelTopGlassTemperatureMeasured->fn->setBackgroundType(PerformanceData_LabelTopGlassTemperatureMeasured, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelTopGlassTemperatureMeasured->fn->setString(PerformanceData_LabelTopGlassTemperatureMeasured, (leString*)&string_TopGlassTemperature);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelTopGlassTemperatureMeasured);

    PerformanceData_LabelWattageCalculated = leLabelWidget_New();
    PerformanceData_LabelWattageCalculated->fn->setPosition(PerformanceData_LabelWattageCalculated, 40, 195);
    PerformanceData_LabelWattageCalculated->fn->setSize(PerformanceData_LabelWattageCalculated, 180, 25);
    PerformanceData_LabelWattageCalculated->fn->setScheme(PerformanceData_LabelWattageCalculated, &BackgroundScheme);
    PerformanceData_LabelWattageCalculated->fn->setBackgroundType(PerformanceData_LabelWattageCalculated, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelWattageCalculated->fn->setString(PerformanceData_LabelWattageCalculated, (leString*)&string_WattageCalculated);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelWattageCalculated);

    PerformanceData_ButtonBack = leButtonWidget_New();
    PerformanceData_ButtonBack->fn->setPosition(PerformanceData_ButtonBack, 431, 4);
    PerformanceData_ButtonBack->fn->setSize(PerformanceData_ButtonBack, 45, 45);
    PerformanceData_ButtonBack->fn->setScheme(PerformanceData_ButtonBack, &ForegroundScheme);
    PerformanceData_ButtonBack->fn->setBackgroundType(PerformanceData_ButtonBack, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_ButtonBack->fn->setBorderType(PerformanceData_ButtonBack, LE_WIDGET_BORDER_NONE);
    PerformanceData_ButtonBack->fn->setPressedImage(PerformanceData_ButtonBack, (leImage*)&ICON_goBackActive);
    PerformanceData_ButtonBack->fn->setReleasedImage(PerformanceData_ButtonBack, (leImage*)&ICON_goBackInactive);
    PerformanceData_ButtonBack->fn->setPressedEventCallback(PerformanceData_ButtonBack, event_PerformanceData_ButtonBack_OnPressed);
    PerformanceData_ButtonBack->fn->setReleasedEventCallback(PerformanceData_ButtonBack, event_PerformanceData_ButtonBack_OnReleased);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_ButtonBack);

    PerformanceData_LabelVoltageValue = leLabelWidget_New();
    PerformanceData_LabelVoltageValue->fn->setPosition(PerformanceData_LabelVoltageValue, 225, 60);
    PerformanceData_LabelVoltageValue->fn->setSize(PerformanceData_LabelVoltageValue, 100, 30);
    PerformanceData_LabelVoltageValue->fn->setScheme(PerformanceData_LabelVoltageValue, &BackgroundScheme);
    PerformanceData_LabelVoltageValue->fn->setBackgroundType(PerformanceData_LabelVoltageValue, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelVoltageValue->fn->setString(PerformanceData_LabelVoltageValue, (leString*)&string_LineVoltage240);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelVoltageValue);

    PerformanceData_LabelLineFrequencyValue = leLabelWidget_New();
    PerformanceData_LabelLineFrequencyValue->fn->setPosition(PerformanceData_LabelLineFrequencyValue, 225, 105);
    PerformanceData_LabelLineFrequencyValue->fn->setSize(PerformanceData_LabelLineFrequencyValue, 100, 30);
    PerformanceData_LabelLineFrequencyValue->fn->setScheme(PerformanceData_LabelLineFrequencyValue, &BackgroundScheme);
    PerformanceData_LabelLineFrequencyValue->fn->setBackgroundType(PerformanceData_LabelLineFrequencyValue, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelLineFrequencyValue->fn->setString(PerformanceData_LabelLineFrequencyValue, (leString*)&string_LineFrequency60Hz);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelLineFrequencyValue);

    PerformanceData_LabelGlassTempValue = leLabelWidget_New();
    PerformanceData_LabelGlassTempValue->fn->setPosition(PerformanceData_LabelGlassTempValue, 225, 150);
    PerformanceData_LabelGlassTempValue->fn->setSize(PerformanceData_LabelGlassTempValue, 100, 30);
    PerformanceData_LabelGlassTempValue->fn->setScheme(PerformanceData_LabelGlassTempValue, &BackgroundScheme);
    PerformanceData_LabelGlassTempValue->fn->setBackgroundType(PerformanceData_LabelGlassTempValue, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelGlassTempValue->fn->setString(PerformanceData_LabelGlassTempValue, (leString*)&string_TopGlassTemperature80F);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelGlassTempValue);

    PerformanceData_LabelWattageValue = leLabelWidget_New();
    PerformanceData_LabelWattageValue->fn->setPosition(PerformanceData_LabelWattageValue, 225, 190);
    PerformanceData_LabelWattageValue->fn->setSize(PerformanceData_LabelWattageValue, 100, 30);
    PerformanceData_LabelWattageValue->fn->setScheme(PerformanceData_LabelWattageValue, &BackgroundScheme);
    PerformanceData_LabelWattageValue->fn->setBackgroundType(PerformanceData_LabelWattageValue, LE_WIDGET_BACKGROUND_NONE);
    PerformanceData_LabelWattageValue->fn->setString(PerformanceData_LabelWattageValue, (leString*)&string_WattageMeasured2200);
    root0->fn->addChild(root0, (leWidget*)PerformanceData_LabelWattageValue);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_PerformanceData(void)
{
}

void screenHide_PerformanceData(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    PerformanceData_Layer0_FillPanel = NULL;
    PerformanceData_PerformaceDataIcon = NULL;
    PerformanceData_LabelOperationalData = NULL;
    PerformanceData_LabelVoltageMeasured = NULL;
    PerformanceData_LabelFrequencyZeroCross = NULL;
    PerformanceData_LabelTopGlassTemperatureMeasured = NULL;
    PerformanceData_LabelWattageCalculated = NULL;
    PerformanceData_ButtonBack = NULL;
    PerformanceData_LabelVoltageValue = NULL;
    PerformanceData_LabelLineFrequencyValue = NULL;
    PerformanceData_LabelGlassTempValue = NULL;
    PerformanceData_LabelWattageValue = NULL;


    showing = LE_FALSE;
}

void screenDestroy_PerformanceData(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_PerformanceData(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

