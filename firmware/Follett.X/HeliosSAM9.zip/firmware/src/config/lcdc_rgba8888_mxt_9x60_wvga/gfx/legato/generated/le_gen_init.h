#ifndef LEGATO_INIT_H
#define LEGATO_INIT_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

#include "gfx/legato/generated/screen/le_gen_screen_Home.h"
#include "gfx/legato/generated/screen/le_gen_screen_SelectCookMode.h"
#include "gfx/legato/generated/screen/le_gen_screen_PowerModeSingle.h"
#include "gfx/legato/generated/screen/le_gen_screen_TemperatureModeSingle.h"
#include "gfx/legato/generated/screen/le_gen_screen_TimerInit.h"
#include "gfx/legato/generated/screen/le_gen_screen_Settings.h"
#include "gfx/legato/generated/screen/le_gen_screen_Error.h"
#include "gfx/legato/generated/screen/le_gen_screen_PerformanceData.h"
#include "gfx/legato/generated/screen/le_gen_screen_ErrorLog.h"
#include "gfx/legato/generated/screen/le_gen_screen_FirmwareVersions.h"
#include "gfx/legato/generated/screen/le_gen_screen_ServicePassCode.h"
#include "gfx/legato/generated/screen/le_gen_screen_ServiceAgentSettingsMaximumWattage.h"
#include "gfx/legato/generated/screen/le_gen_screen_ServiceAgentSettingsVoltageCalibration.h"
#include "gfx/legato/generated/screen/le_gen_screen_ServiceAgentSettingsLimitMaximumCurrent.h"
#include "gfx/legato/generated/screen/le_gen_screen_TemperatureScale.h"
#include "gfx/legato/generated/screen/le_gen_screen_ScreenBrightness1.h"
#include "gfx/legato/generated/screen/le_gen_screen_ServiceMenu.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen IDs
#define screenID_Home    0
#define screenID_SelectCookMode    1
#define screenID_PowerModeSingle    2
#define screenID_TemperatureModeSingle    3
#define screenID_TimerInit    4
#define screenID_Settings    5
#define screenID_Error    6
#define screenID_PerformanceData    7
#define screenID_ErrorLog    8
#define screenID_FirmwareVersions    9
#define screenID_ServicePassCode    10
#define screenID_ServiceAgentSettingsMaximumWattage    11
#define screenID_ServiceAgentSettingsVoltageCalibration    12
#define screenID_ServiceAgentSettingsLimitMaximumCurrent    13
#define screenID_TemperatureScale    14
#define screenID_ScreenBrightness1    15
#define screenID_ServiceMenu    16

void legato_initializeScreenState(void);

// global screen control functions
uint32_t legato_getCurrentScreen(void);
void legato_showScreen(uint32_t id);
void legato_updateScreenState(void);

// do not do anything in the application if this returns true
leBool legato_isChangingScreens(void);


//DOM-IGNORE-BEGIN

#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LEGATO_INIT_H
