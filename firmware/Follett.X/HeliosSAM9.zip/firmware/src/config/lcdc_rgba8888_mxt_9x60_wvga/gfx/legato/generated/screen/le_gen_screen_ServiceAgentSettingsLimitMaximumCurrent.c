#include "gfx/legato/generated/screen/le_gen_screen_ServiceAgentSettingsLimitMaximumCurrent.h"

// screen member widget declarations
leWidget* root0;

leWidget* ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel;
leImageWidget* ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon;
leLabelWidget* ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel;
leLabelWidget* ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent;
leButtonWidget* ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable;
leButtonWidget* ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable;
leLabelWidget* ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog;
leButtonWidget* ServiceAgentSettingsLimitMaximumCurrent_ButtonReset;
leButtonWidget* ServiceAgentSettingsLimitMaximumCurrent_ButtonBack;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_ServiceAgentSettingsLimitMaximumCurrent(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_ServiceAgentSettingsLimitMaximumCurrent(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel = leWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel, 0, 0);
    ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel, 480, 272);
    ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel, &BackgroundScheme);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel);

    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon = leImageWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, 5, 5);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, 40, 40);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, &BackgroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setBorderType(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon->fn->setImage(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon, (leImage*)&gear);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon);

    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel = leLabelWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel, 45, 5);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel, 200, 25);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel, &BackgroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel, (leString*)&string_OtherSettings);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel);

    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent = leLabelWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, 40, 80);
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, 400, 25);
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setHAlignment(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, LE_HALIGN_CENTER);
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent, (leString*)&string_CurrentLimitMaximum);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent);

    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable = leButtonWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, 86, 105);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, 145, 60);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setBorderType(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, (leString*)&string_Disable);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setPressedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, (leImage*)&ICON_settingsActiveL);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setReleasedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, (leImage*)&ICON_settingsActiveL);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable->fn->setImagePosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable, LE_RELATIVE_POSITION_BEHIND);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable);

    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable = leButtonWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, 230, 105);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, 145, 60);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setBorderType(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, (leString*)&string_Enable);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setPressedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, (leImage*)&ICON_settingsActiveR);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setReleasedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, (leImage*)&ICON_settingsInactiveR);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable->fn->setImagePosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable, LE_RELATIVE_POSITION_BEHIND);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable);

    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog = leLabelWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, 40, 180);
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, 400, 25);
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setHAlignment(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, LE_HALIGN_CENTER);
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog, (leString*)&string_ErrorLogReset);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog);

    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset = leButtonWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, 180, 215);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, 120, 40);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setBorderType(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, LE_WIDGET_BORDER_LINE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset->fn->setString(ServiceAgentSettingsLimitMaximumCurrent_ButtonReset, (leString*)&string_Reset);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_ButtonReset);

    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack = leButtonWidget_New();
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setPosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, 431, 7);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setSize(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, 45, 35);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setScheme(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, &ForegroundScheme);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setBackgroundType(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, LE_WIDGET_BACKGROUND_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setBorderType(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, LE_WIDGET_BORDER_NONE);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setPressedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, (leImage*)&ICON_goBackActive);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setReleasedImage(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, (leImage*)&ICON_goBackInactive);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setImagePosition(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, LE_RELATIVE_POSITION_BEHIND);
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack->fn->setReleasedEventCallback(ServiceAgentSettingsLimitMaximumCurrent_ButtonBack, event_ServiceAgentSettingsLimitMaximumCurrent_ButtonBack_OnReleased);
    root0->fn->addChild(root0, (leWidget*)ServiceAgentSettingsLimitMaximumCurrent_ButtonBack);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGBA_8888);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_ServiceAgentSettingsLimitMaximumCurrent(void)
{
}

void screenHide_ServiceAgentSettingsLimitMaximumCurrent(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    ServiceAgentSettingsLimitMaximumCurrent_Layer0_FillPanel = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenIcon = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_CurrentScreenLabel = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_LabelLimitMaximumCurrent = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_ButtonDisable = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_ButtonEnable = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_ResetErrorLog = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_ButtonReset = NULL;
    ServiceAgentSettingsLimitMaximumCurrent_ButtonBack = NULL;


    showing = LE_FALSE;
}

void screenDestroy_ServiceAgentSettingsLimitMaximumCurrent(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_ServiceAgentSettingsLimitMaximumCurrent(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

