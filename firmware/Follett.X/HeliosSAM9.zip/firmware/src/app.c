#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "peripheral/pio/plib_pio.h"
#include "gfx/legato/generated/le_gen_init.h"
#include "system/time/sys_time.h"
#include "gfx/legato/legato.h"
#include "gfx/legato/widget/legato_widget.h"
#include "gfx/legato/widget/button/legato_widget_button.h"
#include "bsp/bsp.h"
#include "configuration.h"
#include "screens/home.h"
#include "app.h"
#include "app_modbus.h"
#include "app_modbus2.h"
#include "screens/temperature.h"
#include "peripheral/pwm/plib_pwm.h"

typedef enum
{
  INIT = 0,
  START_UI,
  STANDBY
}STATES;

// typedef struct
// {
//   int32_t state;  // application's current state
// }APP_DATA;
// static APP_DATA appData;

static uint32_t state;  // application's current state
static int SecondCounter;
int PreviousScreen = screenID_Home;
int ModbusSendCounter;
extern int powerLevelValue;
extern int tempValue;
extern int setTempValue;
extern int tempUnits;
//bool sent;

int testLEDCount;
int testLEDSeconds;
int buttonPressed;
int aState;
int bState;
int aLastState;
int encoderCounter;

void encoderCallback(PIO_PIN pin, uintptr_t context)
{
    if(pin == GPIO_PA23_PIN)
    {
        buttonPressed = 1;
    }
}

void APP_Initialize(void)
{
  ModbusInitSerialPort();
  ModbusInitSerialPort2();
  state = START_UI;
  powerLevelValue=0;  
  tempValue = 79;
  buttonPressed = 0;
  setTempValue = 84;
  tempUnits=0;
  testLEDCount=0;
  testLEDSeconds=0;
  aState=0;
  bState=0;
  aLastState=0;
  
  PWM_ChannelDutySet(PWM_CHANNEL_2,800); // White
  PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
  PWM_ChannelsStart(PWM_CHANNEL_2_MASK);
  PWM_ChannelsStart(PWM_CHANNEL_3_MASK);
  
  PIO_PinInterruptCallbackRegister(GPIO_PA23_PIN, encoderCallback, (uintptr_t)NULL);
  PIO_PinInterruptEnable(GPIO_PA23_PIN);   
}

void APP_Tasks(void)
{
  uint32_t curScreen;
  curScreen = legato_getCurrentScreen();
  
  switch(state)
  {
    case INIT:
      state = START_UI;
      ModbusSendCounter=0;
      sent = false;
      break;
    case START_UI:
      // printf("app.c:APP_Tasks:START_UI\r\n");
      homeScreen();
      state = STANDBY;
      break;
    case STANDBY:
        
      // Check to see if the encoder has been turned
      if(encoderCounter++>400)
      {
        encoderCounter=0;
      
        aState = GPIO_PB0_Get();
        bState = GPIO_PB1_Get();
        if(aState != aLastState)
        {
            if(bState != aState)
            {
                printf("CCW");
            }
            else
            {
                printf("Clockwise");
            }
        }
        aLastState = aState;
      }
      
      // Check to see if the encoder button has been pressed
      if(buttonPressed)
      {
          buttonPressed=0;
          printf("Encoder Button");
      }
      
      // Every Second
      if(SecondCounter++>50000)
      {
        LED_YELLOW_Toggle();                
        SecondCounter=0;
        // ModbusCtrl();
        
        ModbusSendCounter++;
        
        /*if(testLEDCount<6)
        {
            if(testLEDSeconds++>=5)
            {
                testLEDSeconds=0;
                if(testLEDCount==0)
                {
                    testLEDCount++;
                    //PWM_ChannelDutySet(PWM_CHANNEL_0,0); // White
                    //PWM_ChannelDutySet(PWM_CHANNEL_1,1000); // Red
                    
                    PWM_ChannelDutySet(PWM_CHANNEL_2,0); // White
                    PWM_ChannelDutySet(PWM_CHANNEL_3,1000); // Red
                }
                else if(testLEDCount==1)
                {
                    testLEDCount++;
                    //PWM_ChannelDutySet(PWM_CHANNEL_0,1000); // White
                    //PWM_ChannelDutySet(PWM_CHANNEL_1,0); // Red
                    
                    PWM_ChannelDutySet(PWM_CHANNEL_2,1000); // White
                    PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
                }
                else if(testLEDCount==3)
                {
                    testLEDCount++;
                    
                    //PWM_ChannelDutySet(PWM_CHANNEL_0,0); // White
                    //PWM_ChannelDutySet(PWM_CHANNEL_1,1000); // Red
                    
                    PWM_ChannelDutySet(PWM_CHANNEL_2,0); // White
                    PWM_ChannelDutySet(PWM_CHANNEL_3,1000); // Red
                }
                else if(testLEDCount==4)
                {
                    testLEDCount++;
                    
                    //PWM_ChannelDutySet(PWM_CHANNEL_0,1000); // White
                    //PWM_ChannelDutySet(PWM_CHANNEL_1,0); // Red
                    
                    PWM_ChannelDutySet(PWM_CHANNEL_2,1000); // White
                    PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
                }
                else
                {
                    testLEDCount++;
                    //PWM_ChannelDutySet(PWM_CHANNEL_0,0); // White
                    //PWM_ChannelDutySet(PWM_CHANNEL_1,0); // Red
                    
                    PWM_ChannelDutySet(PWM_CHANNEL_2,0); // White
                    PWM_ChannelDutySet(PWM_CHANNEL_3,0); // Red
                }
            }
        }*/
        
        if(modbusReceiveFlag)
        {
            ModbusProcessRecieveData();
            modbusReceiveFlag=false; 
            sent=false; // Send again immediatly
        }
        else if(!sent)
        {            
            ModbusSendCounter=0;
            sent = true;
            ModbusSend();
            //ModbusSend2();
            printf("Sent\r\n");
        }
        else if(ModbusSendCounter>50)
        {
            ModbusSendCounter=0;
            sent=false;
        }
        
        if(curScreen == screenID_TemperatureModeSingle )
        {   
            tempUpdate();
        }
      }
      break;
    default:
      break;
  }
}


void event_Settings_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Exit\r\n");
}
void event_Settings_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("pressed Exit\r\n");
  // show next screen

  printf("PreviousScreen: %d\r\n", PreviousScreen);
  if(PreviousScreen == screenID_PowerModeSingle)
  {
    legato_showScreen(screenID_PowerModeSingle);
  }
  else if(PreviousScreen == screenID_TemperatureModeSingle)
  {
    legato_showScreen(screenID_TemperatureModeSingle);
  }
  else
  {
    printf("PreviousScreen: %d\r\n", PreviousScreen);
  }
}
void event_TemperatureScale_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Exit\r\n");
}
void event_TemperatureScale_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("released Exit\r\n");
  // show next screen
  legato_showScreen(screenID_Settings);
  
}
void event_TemperatureScale_ButtonScaleFahrenheit_OnPressed(leButtonWidget* btn)
{
  // select Fahrenheit as default temperature scale
  //   set Fahrenheit color
  //   reset Centegrade to not default temperature scale
  //   reset Centegrade color
  // nofify ICBM of state change
  // perhaps exit on selection
  printf("pressed Fahrenheit\r\n");
}
void event_TemperatureScale_ButtonScaleFahrenheit_OnReleased(leButtonWidget* btn)
{
  // select Centigrade as default temperature scale
  //   set Centigrade color
  //   reset Fahrenheit to not default temperature scale
  //   reset Fahrenheit color
  // nofify ICBM of state change
  // perhaps exit on selection
  printf("released Fahrenheit\r\n");
}
void event_TemperatureScale_ButtonScaleCentigrade_OnPressed(leButtonWidget* btn)
{
  printf("pressed Centigrade\r\n");
}
void event_TemperatureScale_ButtonScaleCentigrade_OnReleased(leButtonWidget* btn)
{
  printf("released Centigrade\r\n");  
}
void event_Settings_TemperatureScale_OnPressed(leButtonWidget* btn)
{
  printf("pressed Settings Temperature Scale Select\r\n");
}
void event_Settings_TemperatureScale_OnReleased(leButtonWidget* btn)
{
  printf("released Settings Temperature Scale select\r\n");
}
void event_Settings_ButtonTemperatureScale_OnPressed(leButtonWidget* btn)
{
  printf("pressed Temperature Scale Select\r\n");
}
void event_Settings_ButtonTemperatureScale_OnReleased(leButtonWidget* btn)
{
  printf("released Temperature Scale Select\r\n");
  legato_showScreen(screenID_TemperatureScale);
}
void event_Settings_ButtonBrightness_OnPressed(leButtonWidget* btn)
{
  printf("pressed Set Brightness\r\n");
}
void event_Settings_ButtonBrightness_OnReleased(leButtonWidget* btn)
{
  printf("released Set Brightness\r\n");
  legato_showScreen(screenID_ScreenBrightness1);
}
void event_ScreenBrightness_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Back\r\n"); 
}
void event_ScreenBrightness_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("released Back\r\n");
  // show next screen
  legato_showScreen(screenID_Settings);
}
//void event_ScreenBrightness_SliderWidgetBrightness_OnValueChanged(leSliderWidget* scr)
//{
  //  printf("change slider Screen Brightness \r\n");
//}

void ScreenBrightness1_OnHide()
{
    
}
void ScreenBrightness1_OnShow() 
{
    
}

void event_ScreenBrightness1_ButtonBack1_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_Settings);
}
void event_ScreenBrightness1_BrightSlider_OnValueChanged(leSliderWidget* scr)
{
    
}

void event_ServicePassCode_ButtonKey0_OnReleased(leButtonWidget* btn) 
{}

void event_ServicePassCode_ButtonKey1_OnReleased(leButtonWidget* btn)
{}

void event_ServicePassCode_ButtonKey2_OnReleased(leButtonWidget* btn)
{}

void event_ServicePassCode_ButtonKey3_OnReleased(leButtonWidget* btn)
{}

void event_ServicePassCode_ButtonKey4_OnReleased(leButtonWidget* btn)
{}

void event_ServicePassCode_ButtonKey5_OnReleased(leButtonWidget* btn){}
void event_ServicePassCode_ButtonKey6_OnReleased(leButtonWidget* btn){}
void event_ServicePassCode_ButtonKey7_OnReleased(leButtonWidget* btn){}
void event_ServicePassCode_ButtonKey8_OnReleased(leButtonWidget* btn){}
void event_ServicePassCode_ButtonKey9_OnReleased(leButtonWidget* btn){}
void event_ServicePassCode_ButtonKeyBackspace_OnReleased(leButtonWidget* btn){}

void event_ServicePassCode_ButtonKeyEnter_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceMenu);
}

void event_Settings_ButtonPerformanceData_OnPressed(leButtonWidget* btn)
{
  printf("pressed Performance Data\r\n");
}
void event_Settings_ButtonPerformanceData_OnReleased(leButtonWidget* btn)
{
  printf("released Performance Data\r\n");
  legato_showScreen(screenID_PerformanceData);
}
void event_PerformanceData_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Back\r\n");
}
void event_PerformanceData_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("released Back\r\n");
  legato_showScreen(screenID_Settings);
}
void event_Settings_ButtonErrorLog_OnPressed(leButtonWidget* btn)
{
  printf("pressed View Error Log\r\n");
}
void event_Settings_ButtonErrorLog_OnReleased(leButtonWidget* btn)
{
  printf("released View Error Log\r\n");
  legato_showScreen(screenID_ErrorLog);
}
void event_ErrorLog_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Error Log\r\n");
}
void event_ErrorLog_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("released Error Log\r\n");
  legato_showScreen(screenID_Settings);
}
void event_Settings_ButtonFirmwareVersions_OnPressed(leButtonWidget* btn)
{
  printf("pressed FirmwareVersion\r\n");
}
void event_Settings_ButtonFirmwareVersions_OnReleased(leButtonWidget* btn)
{
  printf("released FirmwareVersion\r\n");
  legato_showScreen(screenID_FirmwareVersions);
}
void event_FirmwareVersions_ButtonBack_OnPressed(leButtonWidget* btn)
{
  printf("pressed Back\r\n");
}
void event_FirmwareVersions_ButtonBack_OnReleased(leButtonWidget* btn)
{
  printf("released Back\r\n");
  legato_showScreen(screenID_Settings);
}
void event_Settings_ButtonServiceSettings_OnPressed(leButtonWidget* btn)
{
   printf("pressed Service Tech Settings\r\n");
}
void event_Settings_ButtonServiceSettings_OnReleased(leButtonWidget* btn)
{
   printf("released Service Tech Settings\r\n");
   legato_showScreen(screenID_ServicePassCode);
}


void event_ServicePassCode_ButtonReturn_OnPressed(leButtonWidget* btn)
{
  printf("pressed return\r\n");
}
void event_ServicePassCode_ButtonReturn_OnReleased(leButtonWidget* btn)
{
  printf("released return\r\n");
  legato_showScreen(screenID_Settings);
}

void event_ServiceMenu_BurronWattageSelection_OnPressed(leButtonWidget* btn)
{
    
    printf("Wattage onPressed\r\n");
}

void event_ServiceMenu_BurronWattageSelection_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceAgentSettingsMaximumWattage);
    printf("wattage on released\r\n");
}


void event_ServiceMenu_ButtonLineVoltage_OnPressed(leButtonWidget* btn)
{
    
}
void event_ServiceMenu_ButtonLineVoltage_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceAgentSettingsVoltageCalibration);
    
}
void event_ServiceMenu_ButtonOtherSettings_OnPressed(leButtonWidget* btn)
{
    
}
void event_ServiceMenu_ButtonOtherSettings_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceAgentSettingsLimitMaximumCurrent);
}

void event_ServiceAgentSettingsLimitMaximumCurrent_ButtonBack_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceMenu);
}

void event_ServiceAgentSettingsMaximumWattage_ButtonExit_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceMenu);
}

void event_ServiceAgentSettingsVoltageCalibration_ButtonExit_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_ServiceMenu);
}

void event_ServiceMenu_ButtonBack_OnReleased(leButtonWidget* btn)
{
    legato_showScreen(screenID_Settings);
}


/*******************************************************************************
 End of File
 */

